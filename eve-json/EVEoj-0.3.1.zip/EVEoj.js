(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.EVEoj = f()}})(function(){var define,module,exports;return (function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
/* globals window, HTMLElement */
/**!
 * is
 * the definitive JavaScript type testing library
 *
 * @copyright 2013-2014 Enrico Marino / Jordan Harband
 * @license MIT
 */

var objProto = Object.prototype;
var owns = objProto.hasOwnProperty;
var toStr = objProto.toString;
var symbolValueOf;
if (typeof Symbol === 'function') {
  symbolValueOf = Symbol.prototype.valueOf;
}
var isActualNaN = function (value) {
  return value !== value;
};
var NON_HOST_TYPES = {
  'boolean': 1,
  number: 1,
  string: 1,
  undefined: 1
};

var base64Regex = /^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{4}|[A-Za-z0-9+/]{3}=|[A-Za-z0-9+/]{2}==)$/;
var hexRegex = /^[A-Fa-f0-9]+$/;

/**
 * Expose `is`
 */

var is = module.exports = {};

/**
 * Test general.
 */

/**
 * is.type
 * Test if `value` is a type of `type`.
 *
 * @param {Mixed} value value to test
 * @param {String} type type
 * @return {Boolean} true if `value` is a type of `type`, false otherwise
 * @api public
 */

is.a = is.type = function (value, type) {
  return typeof value === type;
};

/**
 * is.defined
 * Test if `value` is defined.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if 'value' is defined, false otherwise
 * @api public
 */

is.defined = function (value) {
  return typeof value !== 'undefined';
};

/**
 * is.empty
 * Test if `value` is empty.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is empty, false otherwise
 * @api public
 */

is.empty = function (value) {
  var type = toStr.call(value);
  var key;

  if (type === '[object Array]' || type === '[object Arguments]' || type === '[object String]') {
    return value.length === 0;
  }

  if (type === '[object Object]') {
    for (key in value) {
      if (owns.call(value, key)) { return false; }
    }
    return true;
  }

  return !value;
};

/**
 * is.equal
 * Test if `value` is equal to `other`.
 *
 * @param {Mixed} value value to test
 * @param {Mixed} other value to compare with
 * @return {Boolean} true if `value` is equal to `other`, false otherwise
 */

is.equal = function equal(value, other) {
  if (value === other) {
    return true;
  }

  var type = toStr.call(value);
  var key;

  if (type !== toStr.call(other)) {
    return false;
  }

  if (type === '[object Object]') {
    for (key in value) {
      if (!is.equal(value[key], other[key]) || !(key in other)) {
        return false;
      }
    }
    for (key in other) {
      if (!is.equal(value[key], other[key]) || !(key in value)) {
        return false;
      }
    }
    return true;
  }

  if (type === '[object Array]') {
    key = value.length;
    if (key !== other.length) {
      return false;
    }
    while (--key) {
      if (!is.equal(value[key], other[key])) {
        return false;
      }
    }
    return true;
  }

  if (type === '[object Function]') {
    return value.prototype === other.prototype;
  }

  if (type === '[object Date]') {
    return value.getTime() === other.getTime();
  }

  return false;
};

/**
 * is.hosted
 * Test if `value` is hosted by `host`.
 *
 * @param {Mixed} value to test
 * @param {Mixed} host host to test with
 * @return {Boolean} true if `value` is hosted by `host`, false otherwise
 * @api public
 */

is.hosted = function (value, host) {
  var type = typeof host[value];
  return type === 'object' ? !!host[value] : !NON_HOST_TYPES[type];
};

/**
 * is.instance
 * Test if `value` is an instance of `constructor`.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an instance of `constructor`
 * @api public
 */

is.instance = is['instanceof'] = function (value, constructor) {
  return value instanceof constructor;
};

/**
 * is.nil / is.null
 * Test if `value` is null.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is null, false otherwise
 * @api public
 */

is.nil = is['null'] = function (value) {
  return value === null;
};

/**
 * is.undef / is.undefined
 * Test if `value` is undefined.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is undefined, false otherwise
 * @api public
 */

is.undef = is.undefined = function (value) {
  return typeof value === 'undefined';
};

/**
 * Test arguments.
 */

/**
 * is.args
 * Test if `value` is an arguments object.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an arguments object, false otherwise
 * @api public
 */

is.args = is.arguments = function (value) {
  var isStandardArguments = toStr.call(value) === '[object Arguments]';
  var isOldArguments = !is.array(value) && is.arraylike(value) && is.object(value) && is.fn(value.callee);
  return isStandardArguments || isOldArguments;
};

/**
 * Test array.
 */

/**
 * is.array
 * Test if 'value' is an array.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an array, false otherwise
 * @api public
 */

is.array = Array.isArray || function (value) {
  return toStr.call(value) === '[object Array]';
};

/**
 * is.arguments.empty
 * Test if `value` is an empty arguments object.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an empty arguments object, false otherwise
 * @api public
 */
is.args.empty = function (value) {
  return is.args(value) && value.length === 0;
};

/**
 * is.array.empty
 * Test if `value` is an empty array.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an empty array, false otherwise
 * @api public
 */
is.array.empty = function (value) {
  return is.array(value) && value.length === 0;
};

/**
 * is.arraylike
 * Test if `value` is an arraylike object.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an arguments object, false otherwise
 * @api public
 */

is.arraylike = function (value) {
  return !!value && !is.bool(value)
    && owns.call(value, 'length')
    && isFinite(value.length)
    && is.number(value.length)
    && value.length >= 0;
};

/**
 * Test boolean.
 */

/**
 * is.bool
 * Test if `value` is a boolean.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a boolean, false otherwise
 * @api public
 */

is.bool = is['boolean'] = function (value) {
  return toStr.call(value) === '[object Boolean]';
};

/**
 * is.false
 * Test if `value` is false.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is false, false otherwise
 * @api public
 */

is['false'] = function (value) {
  return is.bool(value) && Boolean(Number(value)) === false;
};

/**
 * is.true
 * Test if `value` is true.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is true, false otherwise
 * @api public
 */

is['true'] = function (value) {
  return is.bool(value) && Boolean(Number(value)) === true;
};

/**
 * Test date.
 */

/**
 * is.date
 * Test if `value` is a date.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a date, false otherwise
 * @api public
 */

is.date = function (value) {
  return toStr.call(value) === '[object Date]';
};

/**
 * Test element.
 */

/**
 * is.element
 * Test if `value` is an html element.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an HTML Element, false otherwise
 * @api public
 */

is.element = function (value) {
  return value !== undefined
    && typeof HTMLElement !== 'undefined'
    && value instanceof HTMLElement
    && value.nodeType === 1;
};

/**
 * Test error.
 */

/**
 * is.error
 * Test if `value` is an error object.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an error object, false otherwise
 * @api public
 */

is.error = function (value) {
  return toStr.call(value) === '[object Error]';
};

/**
 * Test function.
 */

/**
 * is.fn / is.function (deprecated)
 * Test if `value` is a function.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a function, false otherwise
 * @api public
 */

is.fn = is['function'] = function (value) {
  var isAlert = typeof window !== 'undefined' && value === window.alert;
  return isAlert || toStr.call(value) === '[object Function]';
};

/**
 * Test number.
 */

/**
 * is.number
 * Test if `value` is a number.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a number, false otherwise
 * @api public
 */

is.number = function (value) {
  return toStr.call(value) === '[object Number]';
};

/**
 * is.infinite
 * Test if `value` is positive or negative infinity.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is positive or negative Infinity, false otherwise
 * @api public
 */
is.infinite = function (value) {
  return value === Infinity || value === -Infinity;
};

/**
 * is.decimal
 * Test if `value` is a decimal number.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a decimal number, false otherwise
 * @api public
 */

is.decimal = function (value) {
  return is.number(value) && !isActualNaN(value) && !is.infinite(value) && value % 1 !== 0;
};

/**
 * is.divisibleBy
 * Test if `value` is divisible by `n`.
 *
 * @param {Number} value value to test
 * @param {Number} n dividend
 * @return {Boolean} true if `value` is divisible by `n`, false otherwise
 * @api public
 */

is.divisibleBy = function (value, n) {
  var isDividendInfinite = is.infinite(value);
  var isDivisorInfinite = is.infinite(n);
  var isNonZeroNumber = is.number(value) && !isActualNaN(value) && is.number(n) && !isActualNaN(n) && n !== 0;
  return isDividendInfinite || isDivisorInfinite || (isNonZeroNumber && value % n === 0);
};

/**
 * is.integer
 * Test if `value` is an integer.
 *
 * @param value to test
 * @return {Boolean} true if `value` is an integer, false otherwise
 * @api public
 */

is.integer = is['int'] = function (value) {
  return is.number(value) && !isActualNaN(value) && value % 1 === 0;
};

/**
 * is.maximum
 * Test if `value` is greater than 'others' values.
 *
 * @param {Number} value value to test
 * @param {Array} others values to compare with
 * @return {Boolean} true if `value` is greater than `others` values
 * @api public
 */

is.maximum = function (value, others) {
  if (isActualNaN(value)) {
    throw new TypeError('NaN is not a valid value');
  } else if (!is.arraylike(others)) {
    throw new TypeError('second argument must be array-like');
  }
  var len = others.length;

  while (--len >= 0) {
    if (value < others[len]) {
      return false;
    }
  }

  return true;
};

/**
 * is.minimum
 * Test if `value` is less than `others` values.
 *
 * @param {Number} value value to test
 * @param {Array} others values to compare with
 * @return {Boolean} true if `value` is less than `others` values
 * @api public
 */

is.minimum = function (value, others) {
  if (isActualNaN(value)) {
    throw new TypeError('NaN is not a valid value');
  } else if (!is.arraylike(others)) {
    throw new TypeError('second argument must be array-like');
  }
  var len = others.length;

  while (--len >= 0) {
    if (value > others[len]) {
      return false;
    }
  }

  return true;
};

/**
 * is.nan
 * Test if `value` is not a number.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is not a number, false otherwise
 * @api public
 */

is.nan = function (value) {
  return !is.number(value) || value !== value;
};

/**
 * is.even
 * Test if `value` is an even number.
 *
 * @param {Number} value value to test
 * @return {Boolean} true if `value` is an even number, false otherwise
 * @api public
 */

is.even = function (value) {
  return is.infinite(value) || (is.number(value) && value === value && value % 2 === 0);
};

/**
 * is.odd
 * Test if `value` is an odd number.
 *
 * @param {Number} value value to test
 * @return {Boolean} true if `value` is an odd number, false otherwise
 * @api public
 */

is.odd = function (value) {
  return is.infinite(value) || (is.number(value) && value === value && value % 2 !== 0);
};

/**
 * is.ge
 * Test if `value` is greater than or equal to `other`.
 *
 * @param {Number} value value to test
 * @param {Number} other value to compare with
 * @return {Boolean}
 * @api public
 */

is.ge = function (value, other) {
  if (isActualNaN(value) || isActualNaN(other)) {
    throw new TypeError('NaN is not a valid value');
  }
  return !is.infinite(value) && !is.infinite(other) && value >= other;
};

/**
 * is.gt
 * Test if `value` is greater than `other`.
 *
 * @param {Number} value value to test
 * @param {Number} other value to compare with
 * @return {Boolean}
 * @api public
 */

is.gt = function (value, other) {
  if (isActualNaN(value) || isActualNaN(other)) {
    throw new TypeError('NaN is not a valid value');
  }
  return !is.infinite(value) && !is.infinite(other) && value > other;
};

/**
 * is.le
 * Test if `value` is less than or equal to `other`.
 *
 * @param {Number} value value to test
 * @param {Number} other value to compare with
 * @return {Boolean} if 'value' is less than or equal to 'other'
 * @api public
 */

is.le = function (value, other) {
  if (isActualNaN(value) || isActualNaN(other)) {
    throw new TypeError('NaN is not a valid value');
  }
  return !is.infinite(value) && !is.infinite(other) && value <= other;
};

/**
 * is.lt
 * Test if `value` is less than `other`.
 *
 * @param {Number} value value to test
 * @param {Number} other value to compare with
 * @return {Boolean} if `value` is less than `other`
 * @api public
 */

is.lt = function (value, other) {
  if (isActualNaN(value) || isActualNaN(other)) {
    throw new TypeError('NaN is not a valid value');
  }
  return !is.infinite(value) && !is.infinite(other) && value < other;
};

/**
 * is.within
 * Test if `value` is within `start` and `finish`.
 *
 * @param {Number} value value to test
 * @param {Number} start lower bound
 * @param {Number} finish upper bound
 * @return {Boolean} true if 'value' is is within 'start' and 'finish'
 * @api public
 */
is.within = function (value, start, finish) {
  if (isActualNaN(value) || isActualNaN(start) || isActualNaN(finish)) {
    throw new TypeError('NaN is not a valid value');
  } else if (!is.number(value) || !is.number(start) || !is.number(finish)) {
    throw new TypeError('all arguments must be numbers');
  }
  var isAnyInfinite = is.infinite(value) || is.infinite(start) || is.infinite(finish);
  return isAnyInfinite || (value >= start && value <= finish);
};

/**
 * Test object.
 */

/**
 * is.object
 * Test if `value` is an object.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is an object, false otherwise
 * @api public
 */

is.object = function (value) {
  return toStr.call(value) === '[object Object]';
};

/**
 * is.hash
 * Test if `value` is a hash - a plain object literal.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a hash, false otherwise
 * @api public
 */

is.hash = function (value) {
  return is.object(value) && value.constructor === Object && !value.nodeType && !value.setInterval;
};

/**
 * Test regexp.
 */

/**
 * is.regexp
 * Test if `value` is a regular expression.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a regexp, false otherwise
 * @api public
 */

is.regexp = function (value) {
  return toStr.call(value) === '[object RegExp]';
};

/**
 * Test string.
 */

/**
 * is.string
 * Test if `value` is a string.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if 'value' is a string, false otherwise
 * @api public
 */

is.string = function (value) {
  return toStr.call(value) === '[object String]';
};

/**
 * Test base64 string.
 */

/**
 * is.base64
 * Test if `value` is a valid base64 encoded string.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if 'value' is a base64 encoded string, false otherwise
 * @api public
 */

is.base64 = function (value) {
  return is.string(value) && (!value.length || base64Regex.test(value));
};

/**
 * Test base64 string.
 */

/**
 * is.hex
 * Test if `value` is a valid hex encoded string.
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if 'value' is a hex encoded string, false otherwise
 * @api public
 */

is.hex = function (value) {
  return is.string(value) && (!value.length || hexRegex.test(value));
};

/**
 * is.symbol
 * Test if `value` is an ES6 Symbol
 *
 * @param {Mixed} value value to test
 * @return {Boolean} true if `value` is a Symbol, false otherise
 * @api public
 */

is.symbol = function (value) {
  return typeof Symbol === 'function' && toStr.call(value) === '[object Symbol]' && typeof symbolValueOf.call(value) === 'symbol';
};

},{}],2:[function(require,module,exports){
module.exports = require('./lib/extend');


},{"./lib/extend":3}],3:[function(require,module,exports){
/*!
 * node.extend
 * Copyright 2011, John Resig
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://jquery.org/license
 *
 * @fileoverview
 * Port of jQuery.extend that actually works on node.js
 */
var is = require('is');

function extend() {
  var target = arguments[0] || {};
  var i = 1;
  var length = arguments.length;
  var deep = false;
  var options, name, src, copy, copy_is_array, clone;

  // Handle a deep copy situation
  if (typeof target === 'boolean') {
    deep = target;
    target = arguments[1] || {};
    // skip the boolean and the target
    i = 2;
  }

  // Handle case when target is a string or something (possible in deep copy)
  if (typeof target !== 'object' && !is.fn(target)) {
    target = {};
  }

  for (; i < length; i++) {
    // Only deal with non-null/undefined values
    options = arguments[i]
    if (options != null) {
      if (typeof options === 'string') {
          options = options.split('');
      }
      // Extend the base object
      for (name in options) {
        src = target[name];
        copy = options[name];

        // Prevent never-ending loop
        if (target === copy) {
          continue;
        }

        // Recurse if we're merging plain objects or arrays
        if (deep && copy && (is.hash(copy) || (copy_is_array = is.array(copy)))) {
          if (copy_is_array) {
            copy_is_array = false;
            clone = src && is.array(src) ? src : [];
          } else {
            clone = src && is.hash(src) ? src : {};
          }

          // Never move original objects, clone them
          target[name] = extend(deep, clone, copy);

        // Don't bring in undefined values
        } else if (typeof copy !== 'undefined') {
          target[name] = copy;
        }
      }
    }
  }

  // Return the modified object
  return target;
};

/**
 * @public
 */
extend.version = '1.1.3';

/**
 * Exports module.
 */
module.exports = extend;


},{"is":1}],4:[function(require,module,exports){
exports.M_per_LY = 9.4605284e+15; // meters per lightyear
exports.M_per_AU = 149597870700; // meters per AU

},{}],5:[function(require,module,exports){
exports.Const = require("./Const");
exports.Utils = require("./Utils");
exports.SDD = require("./SDD");
exports.map = require("./map");
if (exports.Utils.isBrowser) {
	exports.IGB = require("./IGB");
}

exports.V_MAJOR = 0;
exports.V_MINOR = 3;
exports.V_PATCH = 1;
exports.VERSION = exports.V_MAJOR + "." + exports.V_MINOR + "." + exports.V_PATCH;

},{"./Const":4,"./IGB":6,"./SDD":12,"./Utils":13,"./map":16}],6:[function(require,module,exports){
/* global jQuery: false */
/* global CCPEVE: false */
var $ = jQuery;

function IGBClick(ev) {
	var corp_id,
		chan,
		cctype,
		trustme,
		trust_req = false,
		href;

	href = $(this).attr("href");
	if (!href.match(/^eve:/i)) return; // huh.. that's odd
	ev.preventDefault();

	if (href.match(/^eve:trust:/i)) trust_req = true;
	href = href.replace(/^eve:\s*/i, "").replace(/^trust:\s*/i, "");

	/*
	if (typeof(navigator) != 'undefined' && navigator.hasOwnProperty('userAgent') && !navigator.userAgent.match(/EVE\-IGB/)) {
		// straight browser detection for IGB
		return;
	}
	*/
	if (typeof(CCPEVE) == "undefined") {
		// impl based detection for IGB
		return;
	}

	corp_id = $(this).data("igb-corpid");
	chan = $(this).data("igb-chan");
	cctype = $(this).data("igb-cctype");
	trustme = $(this).data("igb-trustme");

	if (corp_id && corp_id > 0) CCPEVE.showInfo(2, corp_id);
	if (chan) CCPEVE.joinChannel(chan);
	if (cctype) CCPEVE.createContract(cctype);
	if (trustme) CCPEVE.requestTrust(trustme);
}

$(function() {
	$("a[href^='eve:']").click(IGBClick);
});

},{}],7:[function(require,module,exports){
/* global Promise: false */
var isBrowser = typeof(window) !== "undefined";
var req_browser_ignore = require;
if (isBrowser) {
	// in browser, BlueBird embedded already by uglify
	//console.log("in browser require utils");
	//console.log("Promise: " + Promise);
	module.exports = Promise;
	//module.exports = require("bluebird");
} else {
	// bluebird required in a way that browserify will ignore (since using custom built for standalone)    
	module.exports = req_browser_ignore("bluebird");
}

},{}],8:[function(require,module,exports){
var Utils = require("./Utils");
var req_browser_ignore = require;

if (Utils.isBrowser) {
	// AJAX-based JSON loader; only for browserify/standalone version
	module.exports = require("./SDD.Source.json_browser.js");
} else {
	// nodeFS based JSON loader; required in a way that browserify will ignore
	module.exports = req_browser_ignore("./SDD.Source.json_node.js");
}

},{"./SDD.Source.json_browser.js":9,"./Utils":13}],9:[function(require,module,exports){
var extend = require("node.extend"),
	Source = require("./SDD.Source"),
	Table = require("./SDD.Table"),
	Utils = require("./Utils"),
	Promise = require("./Promise");

var P = exports.P = Utils.create(Source.P); // public methods, inherit from base Source class

exports.D = extend(true, {}, Source.D, {
	// default object properties
	cfg: {
		cache: true,
		datatype: "json",
		timeout: 0
	},
	jsonfiles: {}
});

exports.Create = function(config) {
	var obj = Utils.create(P);
	extend(true, obj, exports.D);
	obj.Config(config);
	return obj;
};

P.Config = function(config) {
	extend(this.cfg, config);
};

function MetainfDone(data, ctx) {
	var tbl,
		newt,
		i;

	if (!data) return Promise.reject(new Error("invalid data object"));
	if (!data.hasOwnProperty("formatID") || data.formatID != "1") return Promise.reject(new Error("unknown data format"));
	if (!data.hasOwnProperty("schema") || !data.hasOwnProperty("version")) return Promise.reject(new Error("data has no version information"));
	if (!data.hasOwnProperty("tables") || !data.hasOwnProperty("tables")) return Promise.reject(new Error("data has no table information"));
	this.version = data.version;
	this.schema = data.schema;
	if (data.hasOwnProperty("verdesc")) this.verdesc = data.verdesc;

	// reset stuff
	this.tables = {};
	this.jsonfiles = {};

	for (tbl in data.tables) {
		if (!data.tables.hasOwnProperty(tbl)) continue;

		// create a new table from our metadata
		newt = Table.Create(tbl, this, data.tables[tbl]);
		this.tables[newt.name] = newt;

		// collect a list of json sources
		for (i = 0; i < newt.segments.length; i++) {
			if (this.jsonfiles.hasOwnProperty(newt.segments[i].tag)) continue;
			this.jsonfiles[newt.segments[i].tag] = {
				loaded: false,
				p: null
			};
		}
	}

	return Promise.resolve({
		context: ctx,
		source: this
	});
}

P.LoadMeta = function(ctx) {
	var self = this;

	if (!this.cfg.hasOwnProperty("path") || typeof this.cfg.path != "string") {
		return Promise.reject(new Error("path is required"));
	}
	if (this.cfg.datatype != "json" && this.cfg.datatype != "jsonp") {
		return Promise.reject(new Error("invalid datatype: " + this.cfg.datatype));
	}

	return Utils.ajaxP(this.cfg.path + "/metainf." + this.cfg.datatype, {
		dataType: this.cfg.datatype,
		cache: this.cfg.cache,
		jsonp: false,
		timeout: this.cfg.timeout
	}).then(function(data) {
		return MetainfDone.apply(self, [data, ctx]);
	});
};

function LoadFileDone(res, rej, ctx, jsf, data) {
	if (!data || !data.hasOwnProperty("tables")) {
		return rej(new Error("invalid data object"));
	} else if (!data.hasOwnProperty("formatID") || data.formatID != "1") {
		return rej(new Error("unknown data format"));
	} else {
		this.jsonfiles[jsf].loaded = true;
		this.jsonfiles[jsf].data = data;
		return res({
			context: ctx,
			tag: jsf,
			data: data
		});
	}
}

P.LoadTag = function(jsf, ctx) {
	var self = this;
	if (this.jsonfiles[jsf].loaded) {
		return Promise.resolve({
			tag: jsf,
			data: this.jsonfiles[jsf].data
		});
	} else if (this.jsonfiles[jsf].p !== null) {
		return this.jsonfiles[jsf].p;
	} else {
		this.jsonfiles[jsf].p = new Promise(function(res, rej) {
			Utils.ajaxP(self.cfg.path + "/" + jsf + "." + self.cfg.datatype, {
				dataType: self.cfg.datatype,
				cache: self.cfg.cache,
				jsonp: false,
				timeout: self.cfg.timeout
			}).then(function(data) {
				LoadFileDone.apply(self, [res, rej, ctx, jsf, data]);
			});
		});
		return this.jsonfiles[jsf].p;
	}
};

},{"./Promise":7,"./SDD.Source":10,"./SDD.Table":11,"./Utils":13,"node.extend":2}],10:[function(require,module,exports){
// var Utils = require('./Utils');
var P = exports.P = {}; // public methods

exports.D = {
	// default object properties
	tables: {},
	version: null,
	verdesc: null,
	schema: null
};

// return promise:
//		reject({context: ctx, source: this, stats: status, error: errmsg});
//		resolve({context: ctx, source: this});
P.LoadMeta = function() {
	return null;
};

P.HasTable = function(tbl) {
	return this.tables.hasOwnProperty(tbl);
};

P.GetTables = function() {
	var tbl_list = [],
		tbl;
	for (tbl in this.tables) {
		if (!this.tables.hasOwnProperty(tbl)) continue;
		tbl_list.push(tbl);
	}

	return tbl_list;
};

P.GetTable = function(tbl) {
	if (!tbl || !this.tables.hasOwnProperty(tbl)) return null;
	return this.tables[tbl];
};

},{}],11:[function(require,module,exports){
var extend = require("node.extend"),
	Utils = require("./Utils"),
	Promise = require("./Promise");

var P = exports.P = {}; // public methods

// default object properties
exports.D = {
	src: null, // the EVEoj.SDD.Source that owns this table
	name: null, // the name of this table
	keyname: null, // the primary key name
	columns: [], // the list of columns
	colmap: {}, // a reverse lookup map for column indexes
	c: null, // shortcut to colmap
	colmeta: {}, // a map of metainfo about each complex column
	subkeys: [], // any subkeys (this implies a nested entry structure)
	data: {}, // the data for this table (shallow references into raw data from source)
	segments: [], // the segment information for this table
	length: 0, // the total number of entries in this table
	loaded: 0 // the total number of currently loaded entries
};
exports.Create = function(name, src, meta) {
	var obj,
		i,
		keyarr;

	obj = Utils.create(P);
	extend(true, obj, exports.D);

	// sort out relevant metadata details
	obj.src = src;
	obj.name = name;

	// determine the source(s) of this table's data
	if (meta.hasOwnProperty("j")) {
		// only one segment and it is stored with other stuff
		obj.segments.push({
			min: 0,
			max: -1,
			tag: meta.j,
			loaded: false,
			p: null
		});
	} else if (meta.hasOwnProperty("s")) {
		//  at least one segment that is stored independently
		for (i = 0; i < meta.s.length; i++) {
			obj.segments.push({
				min: meta.s[i][1],
				max: meta.s[i][2],
				tag: name + "_" + meta.s[i][0],
				loaded: false,
				p: null
			});
		}
	}

	// find out the key info for this table
	if (meta.hasOwnProperty("k")) {
		keyarr = meta.k.split(":");
		obj.keyname = keyarr.shift();
		for (i = 0; i < keyarr.length; i++) obj.subkeys.push(keyarr[i]);
	}

	// add keys to the column definition
	if (obj.keyname) obj.columns.push(obj.keyname);
	else obj.columns.push("index");
	for (i = 0; i < obj.subkeys.length; i++) {
		obj.columns.push(obj.subkeys[i]);
	}

	// add meta columns to column definition
	if (meta.hasOwnProperty("c")) {
		for (i = 0; i < meta.c.length; i++) obj.columns.push(meta.c[i]);
	}

	// create a reverse lookup map for columns
	for (i = 0; i < obj.columns.length; i++) obj.colmap[obj.columns[i]] = i;
	obj.colmap.index = 0;
	obj.c = obj.colmap;

	// grab the colmeta extra info
	if (meta.hasOwnProperty("m")) {
		extend(true, obj.colmeta, meta.m);
	}

	// grab the length
	if (meta.hasOwnProperty("l")) {
		obj.length = meta.l;
	}

	return obj;
};

// get the entry for the key provided; all keys must be numeric values for segmentation
P.GetEntry = function(key) {
	var i,
		nkey,
		skey;

	// get a guaranteed numeric and guaranteed string version of the key; numeric
	// is for segment comparison, string is for object property lookup
	nkey = parseInt(key, 10);
	if (isNaN(nkey)) return null;
	skey = nkey.toString(10);
	if (this.data.hasOwnProperty(skey)) return this.data[skey];

	// if we don't have this key, determine if we ought to by now
	for (i = 0; i < this.segments.length; i++) {
		if (nkey >= this.segments[i].min && (nkey <= this.segments[i].max || this.segments[i].max == -1)) {
			if (this.segments[i].loaded) return null; // the key should be in this segment
			else return false; // the segment isn't loaded yet
		}
	}

	return null;
};

// get the value for the key (or entry array) and column provided
P.GetValue = function(key, col) {
	var entry;
	if (key instanceof Array) entry = key;
	else entry = this.GetEntry(key);
	if (entry === null || entry === false) return entry;
	if (isNaN(col)) {
		if (!this.colmap.hasOwnProperty(col)) return null;
		col = this.colmap[col];
	}
	return entry[col];
};

function UnshiftIndexes(data, indexes) {
	var key, i;
	for (key in data) {
		if (!data.hasOwnProperty(key)) return;
		if (!data[key]) return;
		indexes.push(parseInt(key, 10));
		if (data[key] instanceof Array) {
			for (i = indexes.length - 1; i >= 0; i--) {
				data[key].unshift(indexes[i]);
			}
		} else UnshiftIndexes(data[key], indexes);
		indexes.pop();
	}
}

function SegLoadDone(res, rej, tag, data, done, ctx, progress) {
	var i;
	done.has++;
	for (i = 0; i < this.segments.length; i++) {
		if (this.segments[i].tag != tag) continue;
		if (data.tables.hasOwnProperty(this.name) && data.tables[this.name].hasOwnProperty("d")) {
			if (!data.tables[this.name].hasOwnProperty("U")) {
				// put the indexes into the first columns of every row
				UnshiftIndexes(data.tables[this.name].d, []);
				data.tables[this.name].U = true;
			}
			extend(this.data, data.tables[this.name].d);
			if (data.tables[this.name].hasOwnProperty("L")) {
				this.loaded += data.tables[this.name].L;
			} else if (done.needs == 1) {
				this.loaded = this.length;
			}
			this.segments[i].loaded = true;
		}
		break;
	}
	if (progress !== null) progress({
		context: ctx,
		table: this,
		has: done.has,
		needs: done.needs
	});
	if (done.has >= done.needs) res({
		context: ctx,
		table: this
	});
}

// load data for this table; returns a deferred promise object as this is an async thing
// if key is provided, loads ONLY the segment containing that key
P.Load = function(opts) {
	var self = this,
		all_needs = [],
		nkey,
		skey,
		i,
		segment,
		o = {
			context: null,
			key: null,
			progress: null
		};
	extend(o, opts);

	// figure out which segments need loading
	if (o.key === null) {
		// no key specified; load all segments
		for (i = 0; i < this.segments.length; i++) {
			if (!this.segments[i].loaded) {
				// this segment not yet loaded
				all_needs.push(i);
			}
		}
	} else {
		// determine which segment the key is in
		nkey = parseInt(o.key, 10);
		if (isNaN(nkey)) {
			return Promise.reject(new Error("invalid key; not numeric"));
		}
		skey = nkey.toString(10);
		segment = -1;
		for (i = 0; i < this.segments.length; i++) {
			if (nkey >= this.segments[i].min && (nkey <= this.segments[i].max || this.segments[i].max == -1)) {
				// the key should be in this segment
				segment = i;
				break;
			}
		}

		if (segment === -1) {
			return Promise.reject(new Error("invalid key; no segment contains it"));
		}
		if (!this.segments[segment].loaded) {
			all_needs.push(segment);
		}
	}

	if (all_needs.length < 1) {
		// all required data already loaded
		return Promise.resolve({
			context: o.context,
			table: this
		});
	}

	return new Promise(function(res, rej) {
		var done = {
			needs: all_needs.length,
			has: 0
		};
		var thenDone = function(arg) {
			SegLoadDone.apply(self, [res, rej, arg.tag, arg.data, done, o.context, o.progress]);
		};
		for (i = 0; i < all_needs.length; i++) {
			segment = self.segments[all_needs[i]];
			if (!segment.p) {
				// this segment not pending load
				segment.p = self.src.LoadTag(segment.tag);
			}
			segment.p.then(thenDone);
		}
	});
};

P.ColIter = function(colname) {
	var colnum;
	if (this.colmap.hasOwnProperty(colname)) {
		colnum = this.colmap[colname];
		return function(e) {
			return e[colnum];
		};
	} else return function() {
		return undefined;
	};
};

P.ColPred = function(colname, compare, value) {
	var colnum;
	if (this.colmap.hasOwnProperty(colname)) {
		colnum = this.colmap[colname];
		if (compare == "==" || compare == "eq") return function(e) {
			return e[colnum] == value;
		};
		if (compare == "!=" || compare == "ne") return function(e) {
			return e[colnum] != value;
		};
		if (compare == "===" || compare == "seq") return function(e) {
			return e[colnum] === value;
		};
		if (compare == "!==" || compare == "sne") return function(e) {
			return e[colnum] !== value;
		};
		else if (compare == ">" || compare == "gt") return function(e) {
			return e[colnum] > value;
		};
		else if (compare == ">=" || compare == "gte") return function(e) {
			return e[colnum] >= value;
		};
		else if (compare == "<" || compare == "lt") return function(e) {
			return e[colnum] < value;
		};
		else if (compare == "<=" || compare == "lte") return function(e) {
			return e[colnum] < value;
		};
	} else return function() {
		return false;
	};
};

},{"./Promise":7,"./Utils":13,"node.extend":2}],12:[function(require,module,exports){
// var Utils = require('./Utils');

exports.Source = require("./SDD.Source");
exports.Source.json = require("./SDD.Source.json");
exports.Table = require("./SDD.Table");

// create a new data source of the type specified with the config provided;
// EVEoj.data.Source.<type> handles the implementation details
exports.Create = function(type, config) {
	if (typeof exports.Source[type] === "undefined" || typeof exports.Source[type].Create !== "function") return null;
	return exports.Source[type].Create(config);
};

},{"./SDD.Source":10,"./SDD.Source.json":8,"./SDD.Table":11}],13:[function(require,module,exports){
/* global jQuery: false */
var Promise = require("./Promise");

exports.isBrowser = typeof(window) !== "undefined";

var F = function() {};

exports.create = (typeof Object.create === "function") ?
	Object.create :
	function(o) {
		// object create polyfill (https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/create)
		if (arguments.length > 1) throw Error("Second argument not supported");
		if (o === null) throw Error("Cannot set a null [[Prototype]]");
		if (typeof(o) !== "object") throw TypeError("Argument must be an object");
		F.prototype = o;
		return new F();
	};

exports.FormatNum = function(val, fixed) {
	var stringy = [],
		base = String(Math.floor(val)),
		k = -1,
		i = 0,
		decimals;

	fixed = fixed || 0;

	for (i = base.length - 1; i >= 0; i--) {
		if (k % 3 === 0) {
			k = 1;
			stringy.push(",");
		} else if (k == -1) {
			k = 1;
		} else {
			k++;
		}
		stringy.push(base.charAt(i));
	}
	base = "";
	for (i = stringy.length - 1; i >= 0; i--) {
		base = base.concat(stringy[i]);
	}

	if (fixed > 0) {
		decimals = val.toFixed(fixed);
		base += decimals.substring(decimals.length - fixed - 1);
	}

	return base;
};

var ajaxP = function(url, settings, cb) {
	jQuery.ajax(url, settings).done(function(data, status, jqxhr) {
		cb(null, data);
	}).fail(function(jqxhr, status, error) {
		cb(error, null);
	});
};
exports.ajaxP = Promise.promisify(ajaxP);

},{"./Promise":7}],14:[function(require,module,exports){
var extend = require("node.extend");
var Utils = require("./Utils");

var P = exports.P = {}; // public methods

exports.D = {
	ID: null,
	name: null,
	regionID: null,
	constellationID: null,
	pos: {
		x: null,
		y: null,
		z: null
	},
	posMax: {
		x: null,
		y: null,
		z: null
	},
	posMin: {
		x: null,
		y: null,
		z: null
	},
	border: null,
	fringe: null,
	corridor: null,
	hub: null,
	international: null,
	regional: null,
	constellation: null,
	contiguous: null,
	security: null,
	sec: null,
	radius: null,
	securityClass: null,
	wormholeClassID: null,
	stationCount: null,
	jumps: null
};
exports.Create = function(tbl, ID) {
	var obj,
		sys,
		col,
		nID;

	nID = parseInt(ID, 10);

	sys = tbl.GetEntry(nID);
	if (!sys) return null;
	obj = Utils.create(P);
	extend(true, obj, exports.D);
	col = tbl.colmap;

	obj.ID = nID;
	obj.name = sys[col.solarSystemName];
	obj.regionID = sys[col.regionID];
	obj.constellationID = sys[col.constellationID];
	obj.pos = {
		x: sys[col.center][0],
		y: sys[col.center][1],
		z: sys[col.center][2]
	};
	obj.posMin = {
		x: sys[col.min][0],
		y: sys[col.min][1],
		z: sys[col.min][2]
	};
	obj.posMax = {
		x: sys[col.max][0],
		y: sys[col.max][1],
		z: sys[col.max][2]
	};
	obj.border = sys[col.border];
	obj.fringe = sys[col.fringe];
	obj.corridor = sys[col.corridor];
	obj.hub = sys[col.hub];
	obj.international = sys[col.international];
	obj.regional = sys[col.regional];
	obj.constellation = sys[col.constellation];
	obj.contiguous = sys[col.contiguous];
	obj.security = sys[col.security];
	obj.sec = (obj.security > 0) ? obj.security.toFixed(1) : "0.0";
	obj.radius = sys[col.radius];
	obj.securityClass = sys[col.securityClass];
	obj.wormholeClassID = sys[col.wormholeClassID];
	obj.stationCount = (sys[col.stationCount]) ? sys[col.stationCount] : 0;
	obj.jumps = sys[col.jumps];

	return obj;
};

},{"./Utils":13,"node.extend":2}],15:[function(require,module,exports){
var extend = require("node.extend");
var Utils = require("./Utils");

var P = exports.P = {}; // public methods
exports.D = {
	// default object properties
	curidx: 0,
	map: null,
	keyset: []
};
exports.Create = function(map) {
	var obj,
		key,
		tbl;

	obj = Utils.create(P);
	extend(true, obj, exports.D);
	obj.map = map;
	tbl = map.tables["map" + map.space + "SolarSystems"].tbl;

	for (key in tbl.data) {
		if (!tbl.data.hasOwnProperty(key)) continue;
		obj.keyset.push(key);
	}

	return obj;
};

P.HasNext = function() {
	if (this.curidx < this.keyset.length) return true;
};

P.Next = function() {
	return this.map.GetSystem({
		id: this.keyset[this.curidx++]
	});
};

},{"./Utils":13,"node.extend":2}],16:[function(require,module,exports){
var extend = require("node.extend"),
	Const = require("./Const"),
	Utils = require("./Utils"),
	System = require("./map.System"),
	SystemIter = require("./map.SystemIter"),
	Promise = require("./Promise");

var P = exports.P = {}; // public methods for this class

exports.D = {
	// default properties for new instances
	src: null,
	tables: {},
	sysNameMap: {},
	sysNames: [],
	routeGraph: {},
	space: null,
	loaded: false,
	loadingP: null,
	c: {
		jumps: false,
		planets: false,
		moons: false,
		belts: false,
		gates: false,
		stars: false,
		objects: false,
		landmarks: false
	}
};

var sys_cache = null; // a place to put generated systems so we don't keep re-creating them

exports.Create = function(src, type, config) {
	if (!src || typeof src.HasTable != "function") return null;
	if (type != "K" && type != "X" && type != "J") return null;
	var obj = Utils.create(P);
	extend(true, obj, exports.D);
	if (config) extend(true, obj.c, config);
	obj.src = src;
	obj.space = type;

	return obj;
};

function LoadDone(res, rej, tbl, ctx) {
	var has = 0,
		needs = 0,
		key;

	for (key in this.tables) {
		if (!this.tables.hasOwnProperty(key)) continue;
		needs += this.tables[key].tbl.segments.length;
		if (key == tbl.name) this.tables[key].done = true;
		if (this.tables[key].done) {
			has += this.tables[key].tbl.segments.length;
		}
	}

	if (has >= needs) {
		LoadInit.apply(this);
		res({
			context: ctx,
			map: this
		});
	}
}

function LoadProgress(arg, progress) {
	var has = 0,
		needs = 0,
		key,
		i;

	if (progress === null) return;

	// arg: {context: ctx, table: this, has: done.has, needs: done.needs}
	// ignoring input progress info and counting finished segments ourself
	for (key in this.tables) {
		if (!this.tables.hasOwnProperty(key)) continue;
		needs += this.tables[key].tbl.segments.length;
		for (i = 0; i < this.tables[key].tbl.segments.length; i++) {
			if (this.tables[key].tbl.segments[i].loaded) has++;
		}
	}

	progress({
		context: arg.context,
		map: this,
		has: has,
		needs: needs
	});
}
P.Load = function(opts) {
	var self = this,
		t = this.tables,
		o = {
			context: null,
			progress: null
		};
	extend(o, opts);

	if (this.loaded) return Promise.resolve({
		context: o.context,
		map: this
	});
	if (this.loadingP) return this.loadingP;

	// setup required and optional tables
	t["map" + this.space + "Regions"] = false;
	t["map" + this.space + "Constellations"] = false;
	t["map" + this.space + "SolarSystems"] = false;
	if (this.space == "K" || this.space == "X") {
		if (this.c.jumps) {
			t["map" + this.space + "RegionJumps"] = false;
			t["map" + this.space + "ConstellationJumps"] = false;
			t["map" + this.space + "SolarSystemJumps"] = false;
		}
		if (this.c.belts) t["map" + this.space + "Belts"] = false;
		if (this.c.gates) t["map" + this.space + "Gates"] = false;
		if (this.c.landmarks) t.mapLandmarks = false;
	}
	if (this.c.planets) t["map" + this.space + "Planets"] = false;
	if (this.c.moons) t["map" + this.space + "Moons"] = false;
	if (this.c.stars) t["map" + this.space + "Stars"] = false;
	if (this.c.objects) t["map" + this.space + "SolarSystemObjects"] = false;

	this.loadingP = new Promise(function(res, rej) {
		var thenDone = function(arg) {
			LoadDone.apply(self, [res, rej, arg.table, arg.context]);
		};
		var progressFunc = null;
		var key;
		if (o.progress !== null) {
			progressFunc = function(arg) {
				LoadProgress.apply(self, [arg, o.progress]);
			};
		}
		for (key in t) {
			if (!t.hasOwnProperty(key)) continue;
			t[key] = {
				tbl: self.src.GetTable(key),
				done: false
			};
			if (!t[key].tbl) {
				rej(new Error("source does not contain requested table: " + key));
				return self.loadingP;
			}
			t[key].tbl.Load({
				context: o.context,
				progress: progressFunc
			}).then(thenDone);
		}
	});

	return this.loadingP;
};

function LoadInit() {
	var systbl = this.tables["map" + this.space + "SolarSystems"].tbl,
		colmap = systbl.colmap,
		solarSystemID,
		toSolarSystemID,
		system,
		i,
		sys;

	sys_cache = {};
	for (solarSystemID in systbl.data) {
		if (!systbl.data.hasOwnProperty(solarSystemID)) continue;
		system = systbl.data[solarSystemID];
		this.sysNameMap[system[colmap.solarSystemName]] = parseInt(solarSystemID, 10);
		this.sysNames.push(system[colmap.solarSystemName]);
		if (this.space != "J") {
			// create the routing graph used for path finding
			sys = {
				jumps: [],
				cont: system[colmap.contiguous],
				sec: system[colmap.security].toFixed(1),
				name: system[colmap.solarSystemName]
			};
			for (i = 0; i < system[colmap.jumps].length; i++) {
				toSolarSystemID = system[colmap.jumps][i];
				if (!systbl.data.hasOwnProperty(toSolarSystemID)) continue;
				sys.jumps.push(toSolarSystemID);
			}
			this.routeGraph[solarSystemID] = sys;
		}
	}
	this.sysNames.sort();
}

P.GetSystem = function(input) {
	var nSystemID,
		sSystemID;

	if (!input) return null;
	if (input.hasOwnProperty("name") && this.sysNameMap.hasOwnProperty(input.name)) nSystemID = this.sysNameMap[input.name];
	else if (input.hasOwnProperty("id")) nSystemID = parseInt(input.id, 10);
	else return null;
	sSystemID = nSystemID.toString(10);

	if (!sys_cache.hasOwnProperty(sSystemID)) {
		sys_cache[sSystemID] = System.Create(this.tables["map" + this.space + "SolarSystems"].tbl, nSystemID);
	}
	return sys_cache[sSystemID];
};

P.GetSystems = function() {
	return SystemIter.Create(this);
	// this.tables["map" + this.space + "SolarSystems"].tbl);
};

P.JumpDist = function(fromID, toID) {
	var systbl = this.tables["map" + this.space + "SolarSystems"].tbl,
		colmap = systbl.colmap,
		x1 = systbl.data[fromID][colmap.center][0],
		x2 = systbl.data[toID][colmap.center][0],
		y1 = systbl.data[fromID][colmap.center][1],
		y2 = systbl.data[toID][colmap.center][1],
		z1 = systbl.data[fromID][colmap.center][2],
		z2 = systbl.data[toID][colmap.center][2],
		dist;

	dist = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2) + Math.pow(z1 - z2, 2));
	return dist / Const.M_per_LY;
};

P.Route = function(fromSystemID, toSystemID, avoidList, avoidLow, avoidHi) {
	var route = [],
		avoids = {},
		sFromID,
		sToID,
		solarSystemID,
		currentID,
		systemID,
		nID,
		prevID,
		sys_td,
		td,
		i,
		tmp,
		testset = [],
		test_td,
		testidx,
		dist;

	sFromID = parseInt(fromSystemID, 10).toString(10);
	sToID = parseInt(toSystemID, 10).toString(10);
	if (!this.routeGraph.hasOwnProperty(sFromID) || !this.routeGraph.hasOwnProperty(sToID)) return route;

	// reset the route graph
	for (solarSystemID in this.routeGraph) {
		if (!this.routeGraph.hasOwnProperty(solarSystemID)) continue;
		this.routeGraph[solarSystemID].td = -1;
		this.routeGraph[solarSystemID].prevID = -1;
		this.routeGraph[solarSystemID].visited = false;
	}

	// populate avoid list lookup table
	if (avoidList && avoidList.length > 0) {
		for (i = 0; i < avoidList.length; i++) {
			avoids[avoidList[i]] = true;
		}
	}

	if (sFromID === sToID) return route;

	// swap from/to to match EVE client?
	tmp = sFromID;
	sFromID = sToID;
	sToID = tmp;

	// Dijkstra's to find best route given options provided
	currentID = sFromID;
	this.routeGraph[sFromID].td = 0;
	while (!this.routeGraph[sToID].visited) {
		if (currentID != sFromID) {
			// find next node to try
			test_td = -1;
			testidx = -1;
			for (i = 0; i < testset.length; i++) {
				systemID = testset[i];
				if (this.routeGraph[systemID].visited) continue;
				if (avoids[systemID]) continue;
				sys_td = this.routeGraph[systemID].td;
				if (sys_td > 0 && (test_td == -1 || sys_td < test_td)) {
					currentID = systemID;
					test_td = sys_td;
					testidx = i;
				}
			}
			if (test_td == -1) return route; // no connection
			testset.splice(testidx, 1); // remove the node we just picked from the testset
		}
		for (i = 0; i < this.routeGraph[currentID].jumps.length; i++) {
			nID = this.routeGraph[currentID].jumps[i];
			dist = 1;
			//if (avoidLow && this.routeGraph[nID].sec < 0.5 && this.routeGraph[currentID].sec >= 0.5) dist = 1000;
			if (avoidLow && this.routeGraph[nID].sec < 0.5) dist = 1000;
			//if (avoidHi && this.routeGraph[nID].sec >= 0.5 && this.routeGraph[currentID].sec < 0.5) dist = 1000;
			if (avoidHi && this.routeGraph[nID].sec >= 0.5) dist = 1000;
			td = this.routeGraph[currentID].td + dist;
			if (this.routeGraph[nID].td < 0 || this.routeGraph[nID].td > td) {
				this.routeGraph[nID].td = td;
				this.routeGraph[nID].prevID = currentID;
				testset.push(nID);
			}
		}
		this.routeGraph[currentID].visited = true;
		currentID = 0;
	}

	// get the actual route found
	prevID = this.routeGraph[sToID].prevID;
	while (prevID != sFromID) {
		route.push(parseInt(prevID, 10));
		prevID = this.routeGraph[prevID].prevID;
	}
	route.push(parseInt(sFromID, 10));
	// route.reverse();
	// route.unshift(toSystemID);
	return route;
};

},{"./Const":4,"./Promise":7,"./Utils":13,"./map.System":14,"./map.SystemIter":15,"node.extend":2}]},{},[5])(5)
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJub2RlX21vZHVsZXMvaXMvaW5kZXguanMiLCJub2RlX21vZHVsZXMvbm9kZS5leHRlbmQvaW5kZXguanMiLCJub2RlX21vZHVsZXMvbm9kZS5leHRlbmQvbGliL2V4dGVuZC5qcyIsInNyYy9Db25zdC5qcyIsInNyYy9FVkVvai5qcyIsInNyYy9JR0IuanMiLCJzcmMvUHJvbWlzZS5qcyIsInNyYy9TREQuU291cmNlLmpzb24uanMiLCJzcmMvU0RELlNvdXJjZS5qc29uX2Jyb3dzZXIuanMiLCJzcmMvU0RELlNvdXJjZS5qcyIsInNyYy9TREQuVGFibGUuanMiLCJzcmMvU0RELmpzIiwic3JjL1V0aWxzLmpzIiwic3JjL21hcC5TeXN0ZW0uanMiLCJzcmMvbWFwLlN5c3RlbUl0ZXIuanMiLCJzcmMvbWFwLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3p2QkE7QUFDQTtBQUNBOztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDbEZBO0FBQ0E7QUFDQTs7QUNGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNaQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDNUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaElBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDckNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDMVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1pBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUMzREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzVGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3JDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCIvKiBnbG9iYWxzIHdpbmRvdywgSFRNTEVsZW1lbnQgKi9cbi8qKiFcbiAqIGlzXG4gKiB0aGUgZGVmaW5pdGl2ZSBKYXZhU2NyaXB0IHR5cGUgdGVzdGluZyBsaWJyYXJ5XG4gKlxuICogQGNvcHlyaWdodCAyMDEzLTIwMTQgRW5yaWNvIE1hcmlubyAvIEpvcmRhbiBIYXJiYW5kXG4gKiBAbGljZW5zZSBNSVRcbiAqL1xuXG52YXIgb2JqUHJvdG8gPSBPYmplY3QucHJvdG90eXBlO1xudmFyIG93bnMgPSBvYmpQcm90by5oYXNPd25Qcm9wZXJ0eTtcbnZhciB0b1N0ciA9IG9ialByb3RvLnRvU3RyaW5nO1xudmFyIHN5bWJvbFZhbHVlT2Y7XG5pZiAodHlwZW9mIFN5bWJvbCA9PT0gJ2Z1bmN0aW9uJykge1xuICBzeW1ib2xWYWx1ZU9mID0gU3ltYm9sLnByb3RvdHlwZS52YWx1ZU9mO1xufVxudmFyIGlzQWN0dWFsTmFOID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiB2YWx1ZSAhPT0gdmFsdWU7XG59O1xudmFyIE5PTl9IT1NUX1RZUEVTID0ge1xuICAnYm9vbGVhbic6IDEsXG4gIG51bWJlcjogMSxcbiAgc3RyaW5nOiAxLFxuICB1bmRlZmluZWQ6IDFcbn07XG5cbnZhciBiYXNlNjRSZWdleCA9IC9eKFtBLVphLXowLTkrL117NH0pKihbQS1aYS16MC05Ky9dezR9fFtBLVphLXowLTkrL117M309fFtBLVphLXowLTkrL117Mn09PSkkLztcbnZhciBoZXhSZWdleCA9IC9eW0EtRmEtZjAtOV0rJC87XG5cbi8qKlxuICogRXhwb3NlIGBpc2BcbiAqL1xuXG52YXIgaXMgPSBtb2R1bGUuZXhwb3J0cyA9IHt9O1xuXG4vKipcbiAqIFRlc3QgZ2VuZXJhbC5cbiAqL1xuXG4vKipcbiAqIGlzLnR5cGVcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhIHR5cGUgb2YgYHR5cGVgLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEBwYXJhbSB7U3RyaW5nfSB0eXBlIHR5cGVcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIHR5cGUgb2YgYHR5cGVgLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuYSA9IGlzLnR5cGUgPSBmdW5jdGlvbiAodmFsdWUsIHR5cGUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gdHlwZTtcbn07XG5cbi8qKlxuICogaXMuZGVmaW5lZFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGRlZmluZWQuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiAndmFsdWUnIGlzIGRlZmluZWQsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5kZWZpbmVkID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnO1xufTtcblxuLyoqXG4gKiBpcy5lbXB0eVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGVtcHR5LlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBlbXB0eSwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmVtcHR5ID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHZhciB0eXBlID0gdG9TdHIuY2FsbCh2YWx1ZSk7XG4gIHZhciBrZXk7XG5cbiAgaWYgKHR5cGUgPT09ICdbb2JqZWN0IEFycmF5XScgfHwgdHlwZSA9PT0gJ1tvYmplY3QgQXJndW1lbnRzXScgfHwgdHlwZSA9PT0gJ1tvYmplY3QgU3RyaW5nXScpIHtcbiAgICByZXR1cm4gdmFsdWUubGVuZ3RoID09PSAwO1xuICB9XG5cbiAgaWYgKHR5cGUgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgZm9yIChrZXkgaW4gdmFsdWUpIHtcbiAgICAgIGlmIChvd25zLmNhbGwodmFsdWUsIGtleSkpIHsgcmV0dXJuIGZhbHNlOyB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xuICB9XG5cbiAgcmV0dXJuICF2YWx1ZTtcbn07XG5cbi8qKlxuICogaXMuZXF1YWxcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBlcXVhbCB0byBgb3RoZXJgLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEBwYXJhbSB7TWl4ZWR9IG90aGVyIHZhbHVlIHRvIGNvbXBhcmUgd2l0aFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGVxdWFsIHRvIGBvdGhlcmAsIGZhbHNlIG90aGVyd2lzZVxuICovXG5cbmlzLmVxdWFsID0gZnVuY3Rpb24gZXF1YWwodmFsdWUsIG90aGVyKSB7XG4gIGlmICh2YWx1ZSA9PT0gb3RoZXIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuXG4gIHZhciB0eXBlID0gdG9TdHIuY2FsbCh2YWx1ZSk7XG4gIHZhciBrZXk7XG5cbiAgaWYgKHR5cGUgIT09IHRvU3RyLmNhbGwob3RoZXIpKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgaWYgKHR5cGUgPT09ICdbb2JqZWN0IE9iamVjdF0nKSB7XG4gICAgZm9yIChrZXkgaW4gdmFsdWUpIHtcbiAgICAgIGlmICghaXMuZXF1YWwodmFsdWVba2V5XSwgb3RoZXJba2V5XSkgfHwgIShrZXkgaW4gb3RoZXIpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgZm9yIChrZXkgaW4gb3RoZXIpIHtcbiAgICAgIGlmICghaXMuZXF1YWwodmFsdWVba2V5XSwgb3RoZXJba2V5XSkgfHwgIShrZXkgaW4gdmFsdWUpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBpZiAodHlwZSA9PT0gJ1tvYmplY3QgQXJyYXldJykge1xuICAgIGtleSA9IHZhbHVlLmxlbmd0aDtcbiAgICBpZiAoa2V5ICE9PSBvdGhlci5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgd2hpbGUgKC0ta2V5KSB7XG4gICAgICBpZiAoIWlzLmVxdWFsKHZhbHVlW2tleV0sIG90aGVyW2tleV0pKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cblxuICBpZiAodHlwZSA9PT0gJ1tvYmplY3QgRnVuY3Rpb25dJykge1xuICAgIHJldHVybiB2YWx1ZS5wcm90b3R5cGUgPT09IG90aGVyLnByb3RvdHlwZTtcbiAgfVxuXG4gIGlmICh0eXBlID09PSAnW29iamVjdCBEYXRlXScpIHtcbiAgICByZXR1cm4gdmFsdWUuZ2V0VGltZSgpID09PSBvdGhlci5nZXRUaW1lKCk7XG4gIH1cblxuICByZXR1cm4gZmFsc2U7XG59O1xuXG4vKipcbiAqIGlzLmhvc3RlZFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGhvc3RlZCBieSBgaG9zdGAuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdG8gdGVzdFxuICogQHBhcmFtIHtNaXhlZH0gaG9zdCBob3N0IHRvIHRlc3Qgd2l0aFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGhvc3RlZCBieSBgaG9zdGAsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5ob3N0ZWQgPSBmdW5jdGlvbiAodmFsdWUsIGhvc3QpIHtcbiAgdmFyIHR5cGUgPSB0eXBlb2YgaG9zdFt2YWx1ZV07XG4gIHJldHVybiB0eXBlID09PSAnb2JqZWN0JyA/ICEhaG9zdFt2YWx1ZV0gOiAhTk9OX0hPU1RfVFlQRVNbdHlwZV07XG59O1xuXG4vKipcbiAqIGlzLmluc3RhbmNlXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgYW4gaW5zdGFuY2Ugb2YgYGNvbnN0cnVjdG9yYC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gaW5zdGFuY2Ugb2YgYGNvbnN0cnVjdG9yYFxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5pbnN0YW5jZSA9IGlzWydpbnN0YW5jZW9mJ10gPSBmdW5jdGlvbiAodmFsdWUsIGNvbnN0cnVjdG9yKSB7XG4gIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIGNvbnN0cnVjdG9yO1xufTtcblxuLyoqXG4gKiBpcy5uaWwgLyBpcy5udWxsXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgbnVsbC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgbnVsbCwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLm5pbCA9IGlzWydudWxsJ10gPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlID09PSBudWxsO1xufTtcblxuLyoqXG4gKiBpcy51bmRlZiAvIGlzLnVuZGVmaW5lZFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIHVuZGVmaW5lZC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgdW5kZWZpbmVkLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMudW5kZWYgPSBpcy51bmRlZmluZWQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCc7XG59O1xuXG4vKipcbiAqIFRlc3QgYXJndW1lbnRzLlxuICovXG5cbi8qKlxuICogaXMuYXJnc1xuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGFyZ3VtZW50cyBvYmplY3QuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGFuIGFyZ3VtZW50cyBvYmplY3QsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5hcmdzID0gaXMuYXJndW1lbnRzID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHZhciBpc1N0YW5kYXJkQXJndW1lbnRzID0gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IEFyZ3VtZW50c10nO1xuICB2YXIgaXNPbGRBcmd1bWVudHMgPSAhaXMuYXJyYXkodmFsdWUpICYmIGlzLmFycmF5bGlrZSh2YWx1ZSkgJiYgaXMub2JqZWN0KHZhbHVlKSAmJiBpcy5mbih2YWx1ZS5jYWxsZWUpO1xuICByZXR1cm4gaXNTdGFuZGFyZEFyZ3VtZW50cyB8fCBpc09sZEFyZ3VtZW50cztcbn07XG5cbi8qKlxuICogVGVzdCBhcnJheS5cbiAqL1xuXG4vKipcbiAqIGlzLmFycmF5XG4gKiBUZXN0IGlmICd2YWx1ZScgaXMgYW4gYXJyYXkuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGFuIGFycmF5LCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuYXJyYXkgPSBBcnJheS5pc0FycmF5IHx8IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IEFycmF5XSc7XG59O1xuXG4vKipcbiAqIGlzLmFyZ3VtZW50cy5lbXB0eVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGVtcHR5IGFyZ3VtZW50cyBvYmplY3QuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGFuIGVtcHR5IGFyZ3VtZW50cyBvYmplY3QsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuaXMuYXJncy5lbXB0eSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gaXMuYXJncyh2YWx1ZSkgJiYgdmFsdWUubGVuZ3RoID09PSAwO1xufTtcblxuLyoqXG4gKiBpcy5hcnJheS5lbXB0eVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGVtcHR5IGFycmF5LlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhbiBlbXB0eSBhcnJheSwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5pcy5hcnJheS5lbXB0eSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gaXMuYXJyYXkodmFsdWUpICYmIHZhbHVlLmxlbmd0aCA9PT0gMDtcbn07XG5cbi8qKlxuICogaXMuYXJyYXlsaWtlXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgYW4gYXJyYXlsaWtlIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gYXJndW1lbnRzIG9iamVjdCwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmFycmF5bGlrZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gISF2YWx1ZSAmJiAhaXMuYm9vbCh2YWx1ZSlcbiAgICAmJiBvd25zLmNhbGwodmFsdWUsICdsZW5ndGgnKVxuICAgICYmIGlzRmluaXRlKHZhbHVlLmxlbmd0aClcbiAgICAmJiBpcy5udW1iZXIodmFsdWUubGVuZ3RoKVxuICAgICYmIHZhbHVlLmxlbmd0aCA+PSAwO1xufTtcblxuLyoqXG4gKiBUZXN0IGJvb2xlYW4uXG4gKi9cblxuLyoqXG4gKiBpcy5ib29sXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgYSBib29sZWFuLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIGJvb2xlYW4sIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5ib29sID0gaXNbJ2Jvb2xlYW4nXSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IEJvb2xlYW5dJztcbn07XG5cbi8qKlxuICogaXMuZmFsc2VcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBmYWxzZS5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgZmFsc2UsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pc1snZmFsc2UnXSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gaXMuYm9vbCh2YWx1ZSkgJiYgQm9vbGVhbihOdW1iZXIodmFsdWUpKSA9PT0gZmFsc2U7XG59O1xuXG4vKipcbiAqIGlzLnRydWVcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyB0cnVlLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyB0cnVlLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXNbJ3RydWUnXSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gaXMuYm9vbCh2YWx1ZSkgJiYgQm9vbGVhbihOdW1iZXIodmFsdWUpKSA9PT0gdHJ1ZTtcbn07XG5cbi8qKlxuICogVGVzdCBkYXRlLlxuICovXG5cbi8qKlxuICogaXMuZGF0ZVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGEgZGF0ZS5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYSBkYXRlLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuZGF0ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IERhdGVdJztcbn07XG5cbi8qKlxuICogVGVzdCBlbGVtZW50LlxuICovXG5cbi8qKlxuICogaXMuZWxlbWVudFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGh0bWwgZWxlbWVudC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gSFRNTCBFbGVtZW50LCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuZWxlbWVudCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgIT09IHVuZGVmaW5lZFxuICAgICYmIHR5cGVvZiBIVE1MRWxlbWVudCAhPT0gJ3VuZGVmaW5lZCdcbiAgICAmJiB2YWx1ZSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50XG4gICAgJiYgdmFsdWUubm9kZVR5cGUgPT09IDE7XG59O1xuXG4vKipcbiAqIFRlc3QgZXJyb3IuXG4gKi9cblxuLyoqXG4gKiBpcy5lcnJvclxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGVycm9yIG9iamVjdC5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gZXJyb3Igb2JqZWN0LCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuZXJyb3IgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIHRvU3RyLmNhbGwodmFsdWUpID09PSAnW29iamVjdCBFcnJvcl0nO1xufTtcblxuLyoqXG4gKiBUZXN0IGZ1bmN0aW9uLlxuICovXG5cbi8qKlxuICogaXMuZm4gLyBpcy5mdW5jdGlvbiAoZGVwcmVjYXRlZClcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhIGZ1bmN0aW9uLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIGZ1bmN0aW9uLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuZm4gPSBpc1snZnVuY3Rpb24nXSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICB2YXIgaXNBbGVydCA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlID09PSB3aW5kb3cuYWxlcnQ7XG4gIHJldHVybiBpc0FsZXJ0IHx8IHRvU3RyLmNhbGwodmFsdWUpID09PSAnW29iamVjdCBGdW5jdGlvbl0nO1xufTtcblxuLyoqXG4gKiBUZXN0IG51bWJlci5cbiAqL1xuXG4vKipcbiAqIGlzLm51bWJlclxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGEgbnVtYmVyLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIG51bWJlciwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLm51bWJlciA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IE51bWJlcl0nO1xufTtcblxuLyoqXG4gKiBpcy5pbmZpbml0ZVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIHBvc2l0aXZlIG9yIG5lZ2F0aXZlIGluZmluaXR5LlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBwb3NpdGl2ZSBvciBuZWdhdGl2ZSBJbmZpbml0eSwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5pcy5pbmZpbml0ZSA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdmFsdWUgPT09IEluZmluaXR5IHx8IHZhbHVlID09PSAtSW5maW5pdHk7XG59O1xuXG4vKipcbiAqIGlzLmRlY2ltYWxcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhIGRlY2ltYWwgbnVtYmVyLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIGRlY2ltYWwgbnVtYmVyLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMuZGVjaW1hbCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gaXMubnVtYmVyKHZhbHVlKSAmJiAhaXNBY3R1YWxOYU4odmFsdWUpICYmICFpcy5pbmZpbml0ZSh2YWx1ZSkgJiYgdmFsdWUgJSAxICE9PSAwO1xufTtcblxuLyoqXG4gKiBpcy5kaXZpc2libGVCeVxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGRpdmlzaWJsZSBieSBgbmAuXG4gKlxuICogQHBhcmFtIHtOdW1iZXJ9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEBwYXJhbSB7TnVtYmVyfSBuIGRpdmlkZW5kXG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgZGl2aXNpYmxlIGJ5IGBuYCwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmRpdmlzaWJsZUJ5ID0gZnVuY3Rpb24gKHZhbHVlLCBuKSB7XG4gIHZhciBpc0RpdmlkZW5kSW5maW5pdGUgPSBpcy5pbmZpbml0ZSh2YWx1ZSk7XG4gIHZhciBpc0Rpdmlzb3JJbmZpbml0ZSA9IGlzLmluZmluaXRlKG4pO1xuICB2YXIgaXNOb25aZXJvTnVtYmVyID0gaXMubnVtYmVyKHZhbHVlKSAmJiAhaXNBY3R1YWxOYU4odmFsdWUpICYmIGlzLm51bWJlcihuKSAmJiAhaXNBY3R1YWxOYU4obikgJiYgbiAhPT0gMDtcbiAgcmV0dXJuIGlzRGl2aWRlbmRJbmZpbml0ZSB8fCBpc0Rpdmlzb3JJbmZpbml0ZSB8fCAoaXNOb25aZXJvTnVtYmVyICYmIHZhbHVlICUgbiA9PT0gMCk7XG59O1xuXG4vKipcbiAqIGlzLmludGVnZXJcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhbiBpbnRlZ2VyLlxuICpcbiAqIEBwYXJhbSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gaW50ZWdlciwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmludGVnZXIgPSBpc1snaW50J10gPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIGlzLm51bWJlcih2YWx1ZSkgJiYgIWlzQWN0dWFsTmFOKHZhbHVlKSAmJiB2YWx1ZSAlIDEgPT09IDA7XG59O1xuXG4vKipcbiAqIGlzLm1heGltdW1cbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBncmVhdGVyIHRoYW4gJ290aGVycycgdmFsdWVzLlxuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcGFyYW0ge0FycmF5fSBvdGhlcnMgdmFsdWVzIHRvIGNvbXBhcmUgd2l0aFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGdyZWF0ZXIgdGhhbiBgb3RoZXJzYCB2YWx1ZXNcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMubWF4aW11bSA9IGZ1bmN0aW9uICh2YWx1ZSwgb3RoZXJzKSB7XG4gIGlmIChpc0FjdHVhbE5hTih2YWx1ZSkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdOYU4gaXMgbm90IGEgdmFsaWQgdmFsdWUnKTtcbiAgfSBlbHNlIGlmICghaXMuYXJyYXlsaWtlKG90aGVycykpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdzZWNvbmQgYXJndW1lbnQgbXVzdCBiZSBhcnJheS1saWtlJyk7XG4gIH1cbiAgdmFyIGxlbiA9IG90aGVycy5sZW5ndGg7XG5cbiAgd2hpbGUgKC0tbGVuID49IDApIHtcbiAgICBpZiAodmFsdWUgPCBvdGhlcnNbbGVuXSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiB0cnVlO1xufTtcblxuLyoqXG4gKiBpcy5taW5pbXVtXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgbGVzcyB0aGFuIGBvdGhlcnNgIHZhbHVlcy5cbiAqXG4gKiBAcGFyYW0ge051bWJlcn0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHBhcmFtIHtBcnJheX0gb3RoZXJzIHZhbHVlcyB0byBjb21wYXJlIHdpdGhcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBsZXNzIHRoYW4gYG90aGVyc2AgdmFsdWVzXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLm1pbmltdW0gPSBmdW5jdGlvbiAodmFsdWUsIG90aGVycykge1xuICBpZiAoaXNBY3R1YWxOYU4odmFsdWUpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTmFOIGlzIG5vdCBhIHZhbGlkIHZhbHVlJyk7XG4gIH0gZWxzZSBpZiAoIWlzLmFycmF5bGlrZShvdGhlcnMpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignc2Vjb25kIGFyZ3VtZW50IG11c3QgYmUgYXJyYXktbGlrZScpO1xuICB9XG4gIHZhciBsZW4gPSBvdGhlcnMubGVuZ3RoO1xuXG4gIHdoaWxlICgtLWxlbiA+PSAwKSB7XG4gICAgaWYgKHZhbHVlID4gb3RoZXJzW2xlbl0pIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdHJ1ZTtcbn07XG5cbi8qKlxuICogaXMubmFuXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgbm90IGEgbnVtYmVyLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBub3QgYSBudW1iZXIsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5uYW4gPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuICFpcy5udW1iZXIodmFsdWUpIHx8IHZhbHVlICE9PSB2YWx1ZTtcbn07XG5cbi8qKlxuICogaXMuZXZlblxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIGV2ZW4gbnVtYmVyLlxuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmIGB2YWx1ZWAgaXMgYW4gZXZlbiBudW1iZXIsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5ldmVuID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiBpcy5pbmZpbml0ZSh2YWx1ZSkgfHwgKGlzLm51bWJlcih2YWx1ZSkgJiYgdmFsdWUgPT09IHZhbHVlICYmIHZhbHVlICUgMiA9PT0gMCk7XG59O1xuXG4vKipcbiAqIGlzLm9kZFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGFuIG9kZCBudW1iZXIuXG4gKlxuICogQHBhcmFtIHtOdW1iZXJ9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhbiBvZGQgbnVtYmVyLCBmYWxzZSBvdGhlcndpc2VcbiAqIEBhcGkgcHVibGljXG4gKi9cblxuaXMub2RkID0gZnVuY3Rpb24gKHZhbHVlKSB7XG4gIHJldHVybiBpcy5pbmZpbml0ZSh2YWx1ZSkgfHwgKGlzLm51bWJlcih2YWx1ZSkgJiYgdmFsdWUgPT09IHZhbHVlICYmIHZhbHVlICUgMiAhPT0gMCk7XG59O1xuXG4vKipcbiAqIGlzLmdlXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgZ3JlYXRlciB0aGFuIG9yIGVxdWFsIHRvIGBvdGhlcmAuXG4gKlxuICogQHBhcmFtIHtOdW1iZXJ9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEBwYXJhbSB7TnVtYmVyfSBvdGhlciB2YWx1ZSB0byBjb21wYXJlIHdpdGhcbiAqIEByZXR1cm4ge0Jvb2xlYW59XG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmdlID0gZnVuY3Rpb24gKHZhbHVlLCBvdGhlcikge1xuICBpZiAoaXNBY3R1YWxOYU4odmFsdWUpIHx8IGlzQWN0dWFsTmFOKG90aGVyKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05hTiBpcyBub3QgYSB2YWxpZCB2YWx1ZScpO1xuICB9XG4gIHJldHVybiAhaXMuaW5maW5pdGUodmFsdWUpICYmICFpcy5pbmZpbml0ZShvdGhlcikgJiYgdmFsdWUgPj0gb3RoZXI7XG59O1xuXG4vKipcbiAqIGlzLmd0XG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgZ3JlYXRlciB0aGFuIGBvdGhlcmAuXG4gKlxuICogQHBhcmFtIHtOdW1iZXJ9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEBwYXJhbSB7TnVtYmVyfSBvdGhlciB2YWx1ZSB0byBjb21wYXJlIHdpdGhcbiAqIEByZXR1cm4ge0Jvb2xlYW59XG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmd0ID0gZnVuY3Rpb24gKHZhbHVlLCBvdGhlcikge1xuICBpZiAoaXNBY3R1YWxOYU4odmFsdWUpIHx8IGlzQWN0dWFsTmFOKG90aGVyKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05hTiBpcyBub3QgYSB2YWxpZCB2YWx1ZScpO1xuICB9XG4gIHJldHVybiAhaXMuaW5maW5pdGUodmFsdWUpICYmICFpcy5pbmZpbml0ZShvdGhlcikgJiYgdmFsdWUgPiBvdGhlcjtcbn07XG5cbi8qKlxuICogaXMubGVcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gYG90aGVyYC5cbiAqXG4gKiBAcGFyYW0ge051bWJlcn0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHBhcmFtIHtOdW1iZXJ9IG90aGVyIHZhbHVlIHRvIGNvbXBhcmUgd2l0aFxuICogQHJldHVybiB7Qm9vbGVhbn0gaWYgJ3ZhbHVlJyBpcyBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gJ290aGVyJ1xuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5sZSA9IGZ1bmN0aW9uICh2YWx1ZSwgb3RoZXIpIHtcbiAgaWYgKGlzQWN0dWFsTmFOKHZhbHVlKSB8fCBpc0FjdHVhbE5hTihvdGhlcikpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdOYU4gaXMgbm90IGEgdmFsaWQgdmFsdWUnKTtcbiAgfVxuICByZXR1cm4gIWlzLmluZmluaXRlKHZhbHVlKSAmJiAhaXMuaW5maW5pdGUob3RoZXIpICYmIHZhbHVlIDw9IG90aGVyO1xufTtcblxuLyoqXG4gKiBpcy5sdFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGxlc3MgdGhhbiBgb3RoZXJgLlxuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcGFyYW0ge051bWJlcn0gb3RoZXIgdmFsdWUgdG8gY29tcGFyZSB3aXRoXG4gKiBAcmV0dXJuIHtCb29sZWFufSBpZiBgdmFsdWVgIGlzIGxlc3MgdGhhbiBgb3RoZXJgXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmx0ID0gZnVuY3Rpb24gKHZhbHVlLCBvdGhlcikge1xuICBpZiAoaXNBY3R1YWxOYU4odmFsdWUpIHx8IGlzQWN0dWFsTmFOKG90aGVyKSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ05hTiBpcyBub3QgYSB2YWxpZCB2YWx1ZScpO1xuICB9XG4gIHJldHVybiAhaXMuaW5maW5pdGUodmFsdWUpICYmICFpcy5pbmZpbml0ZShvdGhlcikgJiYgdmFsdWUgPCBvdGhlcjtcbn07XG5cbi8qKlxuICogaXMud2l0aGluXG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgd2l0aGluIGBzdGFydGAgYW5kIGBmaW5pc2hgLlxuICpcbiAqIEBwYXJhbSB7TnVtYmVyfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcGFyYW0ge051bWJlcn0gc3RhcnQgbG93ZXIgYm91bmRcbiAqIEBwYXJhbSB7TnVtYmVyfSBmaW5pc2ggdXBwZXIgYm91bmRcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgJ3ZhbHVlJyBpcyBpcyB3aXRoaW4gJ3N0YXJ0JyBhbmQgJ2ZpbmlzaCdcbiAqIEBhcGkgcHVibGljXG4gKi9cbmlzLndpdGhpbiA9IGZ1bmN0aW9uICh2YWx1ZSwgc3RhcnQsIGZpbmlzaCkge1xuICBpZiAoaXNBY3R1YWxOYU4odmFsdWUpIHx8IGlzQWN0dWFsTmFOKHN0YXJ0KSB8fCBpc0FjdHVhbE5hTihmaW5pc2gpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignTmFOIGlzIG5vdCBhIHZhbGlkIHZhbHVlJyk7XG4gIH0gZWxzZSBpZiAoIWlzLm51bWJlcih2YWx1ZSkgfHwgIWlzLm51bWJlcihzdGFydCkgfHwgIWlzLm51bWJlcihmaW5pc2gpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignYWxsIGFyZ3VtZW50cyBtdXN0IGJlIG51bWJlcnMnKTtcbiAgfVxuICB2YXIgaXNBbnlJbmZpbml0ZSA9IGlzLmluZmluaXRlKHZhbHVlKSB8fCBpcy5pbmZpbml0ZShzdGFydCkgfHwgaXMuaW5maW5pdGUoZmluaXNoKTtcbiAgcmV0dXJuIGlzQW55SW5maW5pdGUgfHwgKHZhbHVlID49IHN0YXJ0ICYmIHZhbHVlIDw9IGZpbmlzaCk7XG59O1xuXG4vKipcbiAqIFRlc3Qgb2JqZWN0LlxuICovXG5cbi8qKlxuICogaXMub2JqZWN0XG4gKiBUZXN0IGlmIGB2YWx1ZWAgaXMgYW4gb2JqZWN0LlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhbiBvYmplY3QsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5vYmplY3QgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIHRvU3RyLmNhbGwodmFsdWUpID09PSAnW29iamVjdCBPYmplY3RdJztcbn07XG5cbi8qKlxuICogaXMuaGFzaFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGEgaGFzaCAtIGEgcGxhaW4gb2JqZWN0IGxpdGVyYWwuXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGEgaGFzaCwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLmhhc2ggPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIGlzLm9iamVjdCh2YWx1ZSkgJiYgdmFsdWUuY29uc3RydWN0b3IgPT09IE9iamVjdCAmJiAhdmFsdWUubm9kZVR5cGUgJiYgIXZhbHVlLnNldEludGVydmFsO1xufTtcblxuLyoqXG4gKiBUZXN0IHJlZ2V4cC5cbiAqL1xuXG4vKipcbiAqIGlzLnJlZ2V4cFxuICogVGVzdCBpZiBgdmFsdWVgIGlzIGEgcmVndWxhciBleHByZXNzaW9uLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgYHZhbHVlYCBpcyBhIHJlZ2V4cCwgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLnJlZ2V4cCA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IFJlZ0V4cF0nO1xufTtcblxuLyoqXG4gKiBUZXN0IHN0cmluZy5cbiAqL1xuXG4vKipcbiAqIGlzLnN0cmluZ1xuICogVGVzdCBpZiBgdmFsdWVgIGlzIGEgc3RyaW5nLlxuICpcbiAqIEBwYXJhbSB7TWl4ZWR9IHZhbHVlIHZhbHVlIHRvIHRlc3RcbiAqIEByZXR1cm4ge0Jvb2xlYW59IHRydWUgaWYgJ3ZhbHVlJyBpcyBhIHN0cmluZywgZmFsc2Ugb3RoZXJ3aXNlXG4gKiBAYXBpIHB1YmxpY1xuICovXG5cbmlzLnN0cmluZyA9IGZ1bmN0aW9uICh2YWx1ZSkge1xuICByZXR1cm4gdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IFN0cmluZ10nO1xufTtcblxuLyoqXG4gKiBUZXN0IGJhc2U2NCBzdHJpbmcuXG4gKi9cblxuLyoqXG4gKiBpcy5iYXNlNjRcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhIHZhbGlkIGJhc2U2NCBlbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmICd2YWx1ZScgaXMgYSBiYXNlNjQgZW5jb2RlZCBzdHJpbmcsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5iYXNlNjQgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIGlzLnN0cmluZyh2YWx1ZSkgJiYgKCF2YWx1ZS5sZW5ndGggfHwgYmFzZTY0UmVnZXgudGVzdCh2YWx1ZSkpO1xufTtcblxuLyoqXG4gKiBUZXN0IGJhc2U2NCBzdHJpbmcuXG4gKi9cblxuLyoqXG4gKiBpcy5oZXhcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhIHZhbGlkIGhleCBlbmNvZGVkIHN0cmluZy5cbiAqXG4gKiBAcGFyYW0ge01peGVkfSB2YWx1ZSB2YWx1ZSB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSB0cnVlIGlmICd2YWx1ZScgaXMgYSBoZXggZW5jb2RlZCBzdHJpbmcsIGZhbHNlIG90aGVyd2lzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5oZXggPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIGlzLnN0cmluZyh2YWx1ZSkgJiYgKCF2YWx1ZS5sZW5ndGggfHwgaGV4UmVnZXgudGVzdCh2YWx1ZSkpO1xufTtcblxuLyoqXG4gKiBpcy5zeW1ib2xcbiAqIFRlc3QgaWYgYHZhbHVlYCBpcyBhbiBFUzYgU3ltYm9sXG4gKlxuICogQHBhcmFtIHtNaXhlZH0gdmFsdWUgdmFsdWUgdG8gdGVzdFxuICogQHJldHVybiB7Qm9vbGVhbn0gdHJ1ZSBpZiBgdmFsdWVgIGlzIGEgU3ltYm9sLCBmYWxzZSBvdGhlcmlzZVxuICogQGFwaSBwdWJsaWNcbiAqL1xuXG5pcy5zeW1ib2wgPSBmdW5jdGlvbiAodmFsdWUpIHtcbiAgcmV0dXJuIHR5cGVvZiBTeW1ib2wgPT09ICdmdW5jdGlvbicgJiYgdG9TdHIuY2FsbCh2YWx1ZSkgPT09ICdbb2JqZWN0IFN5bWJvbF0nICYmIHR5cGVvZiBzeW1ib2xWYWx1ZU9mLmNhbGwodmFsdWUpID09PSAnc3ltYm9sJztcbn07XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vbGliL2V4dGVuZCcpO1xuXG4iLCIvKiFcbiAqIG5vZGUuZXh0ZW5kXG4gKiBDb3B5cmlnaHQgMjAxMSwgSm9obiBSZXNpZ1xuICogRHVhbCBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIG9yIEdQTCBWZXJzaW9uIDIgbGljZW5zZXMuXG4gKiBodHRwOi8vanF1ZXJ5Lm9yZy9saWNlbnNlXG4gKlxuICogQGZpbGVvdmVydmlld1xuICogUG9ydCBvZiBqUXVlcnkuZXh0ZW5kIHRoYXQgYWN0dWFsbHkgd29ya3Mgb24gbm9kZS5qc1xuICovXG52YXIgaXMgPSByZXF1aXJlKCdpcycpO1xuXG5mdW5jdGlvbiBleHRlbmQoKSB7XG4gIHZhciB0YXJnZXQgPSBhcmd1bWVudHNbMF0gfHwge307XG4gIHZhciBpID0gMTtcbiAgdmFyIGxlbmd0aCA9IGFyZ3VtZW50cy5sZW5ndGg7XG4gIHZhciBkZWVwID0gZmFsc2U7XG4gIHZhciBvcHRpb25zLCBuYW1lLCBzcmMsIGNvcHksIGNvcHlfaXNfYXJyYXksIGNsb25lO1xuXG4gIC8vIEhhbmRsZSBhIGRlZXAgY29weSBzaXR1YXRpb25cbiAgaWYgKHR5cGVvZiB0YXJnZXQgPT09ICdib29sZWFuJykge1xuICAgIGRlZXAgPSB0YXJnZXQ7XG4gICAgdGFyZ2V0ID0gYXJndW1lbnRzWzFdIHx8IHt9O1xuICAgIC8vIHNraXAgdGhlIGJvb2xlYW4gYW5kIHRoZSB0YXJnZXRcbiAgICBpID0gMjtcbiAgfVxuXG4gIC8vIEhhbmRsZSBjYXNlIHdoZW4gdGFyZ2V0IGlzIGEgc3RyaW5nIG9yIHNvbWV0aGluZyAocG9zc2libGUgaW4gZGVlcCBjb3B5KVxuICBpZiAodHlwZW9mIHRhcmdldCAhPT0gJ29iamVjdCcgJiYgIWlzLmZuKHRhcmdldCkpIHtcbiAgICB0YXJnZXQgPSB7fTtcbiAgfVxuXG4gIGZvciAoOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICAvLyBPbmx5IGRlYWwgd2l0aCBub24tbnVsbC91bmRlZmluZWQgdmFsdWVzXG4gICAgb3B0aW9ucyA9IGFyZ3VtZW50c1tpXVxuICAgIGlmIChvcHRpb25zICE9IG51bGwpIHtcbiAgICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICBvcHRpb25zID0gb3B0aW9ucy5zcGxpdCgnJyk7XG4gICAgICB9XG4gICAgICAvLyBFeHRlbmQgdGhlIGJhc2Ugb2JqZWN0XG4gICAgICBmb3IgKG5hbWUgaW4gb3B0aW9ucykge1xuICAgICAgICBzcmMgPSB0YXJnZXRbbmFtZV07XG4gICAgICAgIGNvcHkgPSBvcHRpb25zW25hbWVdO1xuXG4gICAgICAgIC8vIFByZXZlbnQgbmV2ZXItZW5kaW5nIGxvb3BcbiAgICAgICAgaWYgKHRhcmdldCA9PT0gY29weSkge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gUmVjdXJzZSBpZiB3ZSdyZSBtZXJnaW5nIHBsYWluIG9iamVjdHMgb3IgYXJyYXlzXG4gICAgICAgIGlmIChkZWVwICYmIGNvcHkgJiYgKGlzLmhhc2goY29weSkgfHwgKGNvcHlfaXNfYXJyYXkgPSBpcy5hcnJheShjb3B5KSkpKSB7XG4gICAgICAgICAgaWYgKGNvcHlfaXNfYXJyYXkpIHtcbiAgICAgICAgICAgIGNvcHlfaXNfYXJyYXkgPSBmYWxzZTtcbiAgICAgICAgICAgIGNsb25lID0gc3JjICYmIGlzLmFycmF5KHNyYykgPyBzcmMgOiBbXTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2xvbmUgPSBzcmMgJiYgaXMuaGFzaChzcmMpID8gc3JjIDoge307XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gTmV2ZXIgbW92ZSBvcmlnaW5hbCBvYmplY3RzLCBjbG9uZSB0aGVtXG4gICAgICAgICAgdGFyZ2V0W25hbWVdID0gZXh0ZW5kKGRlZXAsIGNsb25lLCBjb3B5KTtcblxuICAgICAgICAvLyBEb24ndCBicmluZyBpbiB1bmRlZmluZWQgdmFsdWVzXG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIGNvcHkgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgdGFyZ2V0W25hbWVdID0gY29weTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8vIFJldHVybiB0aGUgbW9kaWZpZWQgb2JqZWN0XG4gIHJldHVybiB0YXJnZXQ7XG59O1xuXG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXh0ZW5kLnZlcnNpb24gPSAnMS4xLjMnO1xuXG4vKipcbiAqIEV4cG9ydHMgbW9kdWxlLlxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGV4dGVuZDtcblxuIiwiZXhwb3J0cy5NX3Blcl9MWSA9IDkuNDYwNTI4NGUrMTU7IC8vIG1ldGVycyBwZXIgbGlnaHR5ZWFyXG5leHBvcnRzLk1fcGVyX0FVID0gMTQ5NTk3ODcwNzAwOyAvLyBtZXRlcnMgcGVyIEFVXG4iLCJleHBvcnRzLkNvbnN0ID0gcmVxdWlyZShcIi4vQ29uc3RcIik7XG5leHBvcnRzLlV0aWxzID0gcmVxdWlyZShcIi4vVXRpbHNcIik7XG5leHBvcnRzLlNERCA9IHJlcXVpcmUoXCIuL1NERFwiKTtcbmV4cG9ydHMubWFwID0gcmVxdWlyZShcIi4vbWFwXCIpO1xuaWYgKGV4cG9ydHMuVXRpbHMuaXNCcm93c2VyKSB7XG5cdGV4cG9ydHMuSUdCID0gcmVxdWlyZShcIi4vSUdCXCIpO1xufVxuXG5leHBvcnRzLlZfTUFKT1IgPSAwO1xuZXhwb3J0cy5WX01JTk9SID0gMztcbmV4cG9ydHMuVl9QQVRDSCA9IDE7XG5leHBvcnRzLlZFUlNJT04gPSBleHBvcnRzLlZfTUFKT1IgKyBcIi5cIiArIGV4cG9ydHMuVl9NSU5PUiArIFwiLlwiICsgZXhwb3J0cy5WX1BBVENIO1xuIiwiLyogZ2xvYmFsIGpRdWVyeTogZmFsc2UgKi9cbi8qIGdsb2JhbCBDQ1BFVkU6IGZhbHNlICovXG52YXIgJCA9IGpRdWVyeTtcblxuZnVuY3Rpb24gSUdCQ2xpY2soZXYpIHtcblx0dmFyIGNvcnBfaWQsXG5cdFx0Y2hhbixcblx0XHRjY3R5cGUsXG5cdFx0dHJ1c3RtZSxcblx0XHR0cnVzdF9yZXEgPSBmYWxzZSxcblx0XHRocmVmO1xuXG5cdGhyZWYgPSAkKHRoaXMpLmF0dHIoXCJocmVmXCIpO1xuXHRpZiAoIWhyZWYubWF0Y2goL15ldmU6L2kpKSByZXR1cm47IC8vIGh1aC4uIHRoYXQncyBvZGRcblx0ZXYucHJldmVudERlZmF1bHQoKTtcblxuXHRpZiAoaHJlZi5tYXRjaCgvXmV2ZTp0cnVzdDovaSkpIHRydXN0X3JlcSA9IHRydWU7XG5cdGhyZWYgPSBocmVmLnJlcGxhY2UoL15ldmU6XFxzKi9pLCBcIlwiKS5yZXBsYWNlKC9edHJ1c3Q6XFxzKi9pLCBcIlwiKTtcblxuXHQvKlxuXHRpZiAodHlwZW9mKG5hdmlnYXRvcikgIT0gJ3VuZGVmaW5lZCcgJiYgbmF2aWdhdG9yLmhhc093blByb3BlcnR5KCd1c2VyQWdlbnQnKSAmJiAhbmF2aWdhdG9yLnVzZXJBZ2VudC5tYXRjaCgvRVZFXFwtSUdCLykpIHtcblx0XHQvLyBzdHJhaWdodCBicm93c2VyIGRldGVjdGlvbiBmb3IgSUdCXG5cdFx0cmV0dXJuO1xuXHR9XG5cdCovXG5cdGlmICh0eXBlb2YoQ0NQRVZFKSA9PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0Ly8gaW1wbCBiYXNlZCBkZXRlY3Rpb24gZm9yIElHQlxuXHRcdHJldHVybjtcblx0fVxuXG5cdGNvcnBfaWQgPSAkKHRoaXMpLmRhdGEoXCJpZ2ItY29ycGlkXCIpO1xuXHRjaGFuID0gJCh0aGlzKS5kYXRhKFwiaWdiLWNoYW5cIik7XG5cdGNjdHlwZSA9ICQodGhpcykuZGF0YShcImlnYi1jY3R5cGVcIik7XG5cdHRydXN0bWUgPSAkKHRoaXMpLmRhdGEoXCJpZ2ItdHJ1c3RtZVwiKTtcblxuXHRpZiAoY29ycF9pZCAmJiBjb3JwX2lkID4gMCkgQ0NQRVZFLnNob3dJbmZvKDIsIGNvcnBfaWQpO1xuXHRpZiAoY2hhbikgQ0NQRVZFLmpvaW5DaGFubmVsKGNoYW4pO1xuXHRpZiAoY2N0eXBlKSBDQ1BFVkUuY3JlYXRlQ29udHJhY3QoY2N0eXBlKTtcblx0aWYgKHRydXN0bWUpIENDUEVWRS5yZXF1ZXN0VHJ1c3QodHJ1c3RtZSk7XG59XG5cbiQoZnVuY3Rpb24oKSB7XG5cdCQoXCJhW2hyZWZePSdldmU6J11cIikuY2xpY2soSUdCQ2xpY2spO1xufSk7XG4iLCIvKiBnbG9iYWwgUHJvbWlzZTogZmFsc2UgKi9cclxudmFyIGlzQnJvd3NlciA9IHR5cGVvZih3aW5kb3cpICE9PSBcInVuZGVmaW5lZFwiO1xyXG52YXIgcmVxX2Jyb3dzZXJfaWdub3JlID0gcmVxdWlyZTtcclxuaWYgKGlzQnJvd3Nlcikge1xyXG5cdC8vIGluIGJyb3dzZXIsIEJsdWVCaXJkIGVtYmVkZGVkIGFscmVhZHkgYnkgdWdsaWZ5XHJcblx0Ly9jb25zb2xlLmxvZyhcImluIGJyb3dzZXIgcmVxdWlyZSB1dGlsc1wiKTtcclxuXHQvL2NvbnNvbGUubG9nKFwiUHJvbWlzZTogXCIgKyBQcm9taXNlKTtcclxuXHRtb2R1bGUuZXhwb3J0cyA9IFByb21pc2U7XHJcblx0Ly9tb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJibHVlYmlyZFwiKTtcclxufSBlbHNlIHtcclxuXHQvLyBibHVlYmlyZCByZXF1aXJlZCBpbiBhIHdheSB0aGF0IGJyb3dzZXJpZnkgd2lsbCBpZ25vcmUgKHNpbmNlIHVzaW5nIGN1c3RvbSBidWlsdCBmb3Igc3RhbmRhbG9uZSkgICAgXHJcblx0bW9kdWxlLmV4cG9ydHMgPSByZXFfYnJvd3Nlcl9pZ25vcmUoXCJibHVlYmlyZFwiKTtcclxufVxyXG4iLCJ2YXIgVXRpbHMgPSByZXF1aXJlKFwiLi9VdGlsc1wiKTtcbnZhciByZXFfYnJvd3Nlcl9pZ25vcmUgPSByZXF1aXJlO1xuXG5pZiAoVXRpbHMuaXNCcm93c2VyKSB7XG5cdC8vIEFKQVgtYmFzZWQgSlNPTiBsb2FkZXI7IG9ubHkgZm9yIGJyb3dzZXJpZnkvc3RhbmRhbG9uZSB2ZXJzaW9uXG5cdG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIi4vU0RELlNvdXJjZS5qc29uX2Jyb3dzZXIuanNcIik7XG59IGVsc2Uge1xuXHQvLyBub2RlRlMgYmFzZWQgSlNPTiBsb2FkZXI7IHJlcXVpcmVkIGluIGEgd2F5IHRoYXQgYnJvd3NlcmlmeSB3aWxsIGlnbm9yZVxuXHRtb2R1bGUuZXhwb3J0cyA9IHJlcV9icm93c2VyX2lnbm9yZShcIi4vU0RELlNvdXJjZS5qc29uX25vZGUuanNcIik7XG59XG4iLCJ2YXIgZXh0ZW5kID0gcmVxdWlyZShcIm5vZGUuZXh0ZW5kXCIpLFxuXHRTb3VyY2UgPSByZXF1aXJlKFwiLi9TREQuU291cmNlXCIpLFxuXHRUYWJsZSA9IHJlcXVpcmUoXCIuL1NERC5UYWJsZVwiKSxcblx0VXRpbHMgPSByZXF1aXJlKFwiLi9VdGlsc1wiKSxcblx0UHJvbWlzZSA9IHJlcXVpcmUoXCIuL1Byb21pc2VcIik7XG5cbnZhciBQID0gZXhwb3J0cy5QID0gVXRpbHMuY3JlYXRlKFNvdXJjZS5QKTsgLy8gcHVibGljIG1ldGhvZHMsIGluaGVyaXQgZnJvbSBiYXNlIFNvdXJjZSBjbGFzc1xuXG5leHBvcnRzLkQgPSBleHRlbmQodHJ1ZSwge30sIFNvdXJjZS5ELCB7XG5cdC8vIGRlZmF1bHQgb2JqZWN0IHByb3BlcnRpZXNcblx0Y2ZnOiB7XG5cdFx0Y2FjaGU6IHRydWUsXG5cdFx0ZGF0YXR5cGU6IFwianNvblwiLFxuXHRcdHRpbWVvdXQ6IDBcblx0fSxcblx0anNvbmZpbGVzOiB7fVxufSk7XG5cbmV4cG9ydHMuQ3JlYXRlID0gZnVuY3Rpb24oY29uZmlnKSB7XG5cdHZhciBvYmogPSBVdGlscy5jcmVhdGUoUCk7XG5cdGV4dGVuZCh0cnVlLCBvYmosIGV4cG9ydHMuRCk7XG5cdG9iai5Db25maWcoY29uZmlnKTtcblx0cmV0dXJuIG9iajtcbn07XG5cblAuQ29uZmlnID0gZnVuY3Rpb24oY29uZmlnKSB7XG5cdGV4dGVuZCh0aGlzLmNmZywgY29uZmlnKTtcbn07XG5cbmZ1bmN0aW9uIE1ldGFpbmZEb25lKGRhdGEsIGN0eCkge1xuXHR2YXIgdGJsLFxuXHRcdG5ld3QsXG5cdFx0aTtcblxuXHRpZiAoIWRhdGEpIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgRXJyb3IoXCJpbnZhbGlkIGRhdGEgb2JqZWN0XCIpKTtcblx0aWYgKCFkYXRhLmhhc093blByb3BlcnR5KFwiZm9ybWF0SURcIikgfHwgZGF0YS5mb3JtYXRJRCAhPSBcIjFcIikgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcInVua25vd24gZGF0YSBmb3JtYXRcIikpO1xuXHRpZiAoIWRhdGEuaGFzT3duUHJvcGVydHkoXCJzY2hlbWFcIikgfHwgIWRhdGEuaGFzT3duUHJvcGVydHkoXCJ2ZXJzaW9uXCIpKSByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKFwiZGF0YSBoYXMgbm8gdmVyc2lvbiBpbmZvcm1hdGlvblwiKSk7XG5cdGlmICghZGF0YS5oYXNPd25Qcm9wZXJ0eShcInRhYmxlc1wiKSB8fCAhZGF0YS5oYXNPd25Qcm9wZXJ0eShcInRhYmxlc1wiKSkgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcImRhdGEgaGFzIG5vIHRhYmxlIGluZm9ybWF0aW9uXCIpKTtcblx0dGhpcy52ZXJzaW9uID0gZGF0YS52ZXJzaW9uO1xuXHR0aGlzLnNjaGVtYSA9IGRhdGEuc2NoZW1hO1xuXHRpZiAoZGF0YS5oYXNPd25Qcm9wZXJ0eShcInZlcmRlc2NcIikpIHRoaXMudmVyZGVzYyA9IGRhdGEudmVyZGVzYztcblxuXHQvLyByZXNldCBzdHVmZlxuXHR0aGlzLnRhYmxlcyA9IHt9O1xuXHR0aGlzLmpzb25maWxlcyA9IHt9O1xuXG5cdGZvciAodGJsIGluIGRhdGEudGFibGVzKSB7XG5cdFx0aWYgKCFkYXRhLnRhYmxlcy5oYXNPd25Qcm9wZXJ0eSh0YmwpKSBjb250aW51ZTtcblxuXHRcdC8vIGNyZWF0ZSBhIG5ldyB0YWJsZSBmcm9tIG91ciBtZXRhZGF0YVxuXHRcdG5ld3QgPSBUYWJsZS5DcmVhdGUodGJsLCB0aGlzLCBkYXRhLnRhYmxlc1t0YmxdKTtcblx0XHR0aGlzLnRhYmxlc1tuZXd0Lm5hbWVdID0gbmV3dDtcblxuXHRcdC8vIGNvbGxlY3QgYSBsaXN0IG9mIGpzb24gc291cmNlc1xuXHRcdGZvciAoaSA9IDA7IGkgPCBuZXd0LnNlZ21lbnRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRpZiAodGhpcy5qc29uZmlsZXMuaGFzT3duUHJvcGVydHkobmV3dC5zZWdtZW50c1tpXS50YWcpKSBjb250aW51ZTtcblx0XHRcdHRoaXMuanNvbmZpbGVzW25ld3Quc2VnbWVudHNbaV0udGFnXSA9IHtcblx0XHRcdFx0bG9hZGVkOiBmYWxzZSxcblx0XHRcdFx0cDogbnVsbFxuXHRcdFx0fTtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHtcblx0XHRjb250ZXh0OiBjdHgsXG5cdFx0c291cmNlOiB0aGlzXG5cdH0pO1xufVxuXG5QLkxvYWRNZXRhID0gZnVuY3Rpb24oY3R4KSB7XG5cdHZhciBzZWxmID0gdGhpcztcblxuXHRpZiAoIXRoaXMuY2ZnLmhhc093blByb3BlcnR5KFwicGF0aFwiKSB8fCB0eXBlb2YgdGhpcy5jZmcucGF0aCAhPSBcInN0cmluZ1wiKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcInBhdGggaXMgcmVxdWlyZWRcIikpO1xuXHR9XG5cdGlmICh0aGlzLmNmZy5kYXRhdHlwZSAhPSBcImpzb25cIiAmJiB0aGlzLmNmZy5kYXRhdHlwZSAhPSBcImpzb25wXCIpIHtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IEVycm9yKFwiaW52YWxpZCBkYXRhdHlwZTogXCIgKyB0aGlzLmNmZy5kYXRhdHlwZSkpO1xuXHR9XG5cblx0cmV0dXJuIFV0aWxzLmFqYXhQKHRoaXMuY2ZnLnBhdGggKyBcIi9tZXRhaW5mLlwiICsgdGhpcy5jZmcuZGF0YXR5cGUsIHtcblx0XHRkYXRhVHlwZTogdGhpcy5jZmcuZGF0YXR5cGUsXG5cdFx0Y2FjaGU6IHRoaXMuY2ZnLmNhY2hlLFxuXHRcdGpzb25wOiBmYWxzZSxcblx0XHR0aW1lb3V0OiB0aGlzLmNmZy50aW1lb3V0XG5cdH0pLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xuXHRcdHJldHVybiBNZXRhaW5mRG9uZS5hcHBseShzZWxmLCBbZGF0YSwgY3R4XSk7XG5cdH0pO1xufTtcblxuZnVuY3Rpb24gTG9hZEZpbGVEb25lKHJlcywgcmVqLCBjdHgsIGpzZiwgZGF0YSkge1xuXHRpZiAoIWRhdGEgfHwgIWRhdGEuaGFzT3duUHJvcGVydHkoXCJ0YWJsZXNcIikpIHtcblx0XHRyZXR1cm4gcmVqKG5ldyBFcnJvcihcImludmFsaWQgZGF0YSBvYmplY3RcIikpO1xuXHR9IGVsc2UgaWYgKCFkYXRhLmhhc093blByb3BlcnR5KFwiZm9ybWF0SURcIikgfHwgZGF0YS5mb3JtYXRJRCAhPSBcIjFcIikge1xuXHRcdHJldHVybiByZWoobmV3IEVycm9yKFwidW5rbm93biBkYXRhIGZvcm1hdFwiKSk7XG5cdH0gZWxzZSB7XG5cdFx0dGhpcy5qc29uZmlsZXNbanNmXS5sb2FkZWQgPSB0cnVlO1xuXHRcdHRoaXMuanNvbmZpbGVzW2pzZl0uZGF0YSA9IGRhdGE7XG5cdFx0cmV0dXJuIHJlcyh7XG5cdFx0XHRjb250ZXh0OiBjdHgsXG5cdFx0XHR0YWc6IGpzZixcblx0XHRcdGRhdGE6IGRhdGFcblx0XHR9KTtcblx0fVxufVxuXG5QLkxvYWRUYWcgPSBmdW5jdGlvbihqc2YsIGN0eCkge1xuXHR2YXIgc2VsZiA9IHRoaXM7XG5cdGlmICh0aGlzLmpzb25maWxlc1tqc2ZdLmxvYWRlZCkge1xuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuXHRcdFx0dGFnOiBqc2YsXG5cdFx0XHRkYXRhOiB0aGlzLmpzb25maWxlc1tqc2ZdLmRhdGFcblx0XHR9KTtcblx0fSBlbHNlIGlmICh0aGlzLmpzb25maWxlc1tqc2ZdLnAgIT09IG51bGwpIHtcblx0XHRyZXR1cm4gdGhpcy5qc29uZmlsZXNbanNmXS5wO1xuXHR9IGVsc2Uge1xuXHRcdHRoaXMuanNvbmZpbGVzW2pzZl0ucCA9IG5ldyBQcm9taXNlKGZ1bmN0aW9uKHJlcywgcmVqKSB7XG5cdFx0XHRVdGlscy5hamF4UChzZWxmLmNmZy5wYXRoICsgXCIvXCIgKyBqc2YgKyBcIi5cIiArIHNlbGYuY2ZnLmRhdGF0eXBlLCB7XG5cdFx0XHRcdGRhdGFUeXBlOiBzZWxmLmNmZy5kYXRhdHlwZSxcblx0XHRcdFx0Y2FjaGU6IHNlbGYuY2ZnLmNhY2hlLFxuXHRcdFx0XHRqc29ucDogZmFsc2UsXG5cdFx0XHRcdHRpbWVvdXQ6IHNlbGYuY2ZnLnRpbWVvdXRcblx0XHRcdH0pLnRoZW4oZnVuY3Rpb24oZGF0YSkge1xuXHRcdFx0XHRMb2FkRmlsZURvbmUuYXBwbHkoc2VsZiwgW3JlcywgcmVqLCBjdHgsIGpzZiwgZGF0YV0pO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHRoaXMuanNvbmZpbGVzW2pzZl0ucDtcblx0fVxufTtcbiIsIi8vIHZhciBVdGlscyA9IHJlcXVpcmUoJy4vVXRpbHMnKTtcbnZhciBQID0gZXhwb3J0cy5QID0ge307IC8vIHB1YmxpYyBtZXRob2RzXG5cbmV4cG9ydHMuRCA9IHtcblx0Ly8gZGVmYXVsdCBvYmplY3QgcHJvcGVydGllc1xuXHR0YWJsZXM6IHt9LFxuXHR2ZXJzaW9uOiBudWxsLFxuXHR2ZXJkZXNjOiBudWxsLFxuXHRzY2hlbWE6IG51bGxcbn07XG5cbi8vIHJldHVybiBwcm9taXNlOlxuLy9cdFx0cmVqZWN0KHtjb250ZXh0OiBjdHgsIHNvdXJjZTogdGhpcywgc3RhdHM6IHN0YXR1cywgZXJyb3I6IGVycm1zZ30pO1xuLy9cdFx0cmVzb2x2ZSh7Y29udGV4dDogY3R4LCBzb3VyY2U6IHRoaXN9KTtcblAuTG9hZE1ldGEgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIG51bGw7XG59O1xuXG5QLkhhc1RhYmxlID0gZnVuY3Rpb24odGJsKSB7XG5cdHJldHVybiB0aGlzLnRhYmxlcy5oYXNPd25Qcm9wZXJ0eSh0YmwpO1xufTtcblxuUC5HZXRUYWJsZXMgPSBmdW5jdGlvbigpIHtcblx0dmFyIHRibF9saXN0ID0gW10sXG5cdFx0dGJsO1xuXHRmb3IgKHRibCBpbiB0aGlzLnRhYmxlcykge1xuXHRcdGlmICghdGhpcy50YWJsZXMuaGFzT3duUHJvcGVydHkodGJsKSkgY29udGludWU7XG5cdFx0dGJsX2xpc3QucHVzaCh0YmwpO1xuXHR9XG5cblx0cmV0dXJuIHRibF9saXN0O1xufTtcblxuUC5HZXRUYWJsZSA9IGZ1bmN0aW9uKHRibCkge1xuXHRpZiAoIXRibCB8fCAhdGhpcy50YWJsZXMuaGFzT3duUHJvcGVydHkodGJsKSkgcmV0dXJuIG51bGw7XG5cdHJldHVybiB0aGlzLnRhYmxlc1t0YmxdO1xufTtcbiIsInZhciBleHRlbmQgPSByZXF1aXJlKFwibm9kZS5leHRlbmRcIiksXG5cdFV0aWxzID0gcmVxdWlyZShcIi4vVXRpbHNcIiksXG5cdFByb21pc2UgPSByZXF1aXJlKFwiLi9Qcm9taXNlXCIpO1xuXG52YXIgUCA9IGV4cG9ydHMuUCA9IHt9OyAvLyBwdWJsaWMgbWV0aG9kc1xuXG4vLyBkZWZhdWx0IG9iamVjdCBwcm9wZXJ0aWVzXG5leHBvcnRzLkQgPSB7XG5cdHNyYzogbnVsbCwgLy8gdGhlIEVWRW9qLlNERC5Tb3VyY2UgdGhhdCBvd25zIHRoaXMgdGFibGVcblx0bmFtZTogbnVsbCwgLy8gdGhlIG5hbWUgb2YgdGhpcyB0YWJsZVxuXHRrZXluYW1lOiBudWxsLCAvLyB0aGUgcHJpbWFyeSBrZXkgbmFtZVxuXHRjb2x1bW5zOiBbXSwgLy8gdGhlIGxpc3Qgb2YgY29sdW1uc1xuXHRjb2xtYXA6IHt9LCAvLyBhIHJldmVyc2UgbG9va3VwIG1hcCBmb3IgY29sdW1uIGluZGV4ZXNcblx0YzogbnVsbCwgLy8gc2hvcnRjdXQgdG8gY29sbWFwXG5cdGNvbG1ldGE6IHt9LCAvLyBhIG1hcCBvZiBtZXRhaW5mbyBhYm91dCBlYWNoIGNvbXBsZXggY29sdW1uXG5cdHN1YmtleXM6IFtdLCAvLyBhbnkgc3Via2V5cyAodGhpcyBpbXBsaWVzIGEgbmVzdGVkIGVudHJ5IHN0cnVjdHVyZSlcblx0ZGF0YToge30sIC8vIHRoZSBkYXRhIGZvciB0aGlzIHRhYmxlIChzaGFsbG93IHJlZmVyZW5jZXMgaW50byByYXcgZGF0YSBmcm9tIHNvdXJjZSlcblx0c2VnbWVudHM6IFtdLCAvLyB0aGUgc2VnbWVudCBpbmZvcm1hdGlvbiBmb3IgdGhpcyB0YWJsZVxuXHRsZW5ndGg6IDAsIC8vIHRoZSB0b3RhbCBudW1iZXIgb2YgZW50cmllcyBpbiB0aGlzIHRhYmxlXG5cdGxvYWRlZDogMCAvLyB0aGUgdG90YWwgbnVtYmVyIG9mIGN1cnJlbnRseSBsb2FkZWQgZW50cmllc1xufTtcbmV4cG9ydHMuQ3JlYXRlID0gZnVuY3Rpb24obmFtZSwgc3JjLCBtZXRhKSB7XG5cdHZhciBvYmosXG5cdFx0aSxcblx0XHRrZXlhcnI7XG5cblx0b2JqID0gVXRpbHMuY3JlYXRlKFApO1xuXHRleHRlbmQodHJ1ZSwgb2JqLCBleHBvcnRzLkQpO1xuXG5cdC8vIHNvcnQgb3V0IHJlbGV2YW50IG1ldGFkYXRhIGRldGFpbHNcblx0b2JqLnNyYyA9IHNyYztcblx0b2JqLm5hbWUgPSBuYW1lO1xuXG5cdC8vIGRldGVybWluZSB0aGUgc291cmNlKHMpIG9mIHRoaXMgdGFibGUncyBkYXRhXG5cdGlmIChtZXRhLmhhc093blByb3BlcnR5KFwialwiKSkge1xuXHRcdC8vIG9ubHkgb25lIHNlZ21lbnQgYW5kIGl0IGlzIHN0b3JlZCB3aXRoIG90aGVyIHN0dWZmXG5cdFx0b2JqLnNlZ21lbnRzLnB1c2goe1xuXHRcdFx0bWluOiAwLFxuXHRcdFx0bWF4OiAtMSxcblx0XHRcdHRhZzogbWV0YS5qLFxuXHRcdFx0bG9hZGVkOiBmYWxzZSxcblx0XHRcdHA6IG51bGxcblx0XHR9KTtcblx0fSBlbHNlIGlmIChtZXRhLmhhc093blByb3BlcnR5KFwic1wiKSkge1xuXHRcdC8vICBhdCBsZWFzdCBvbmUgc2VnbWVudCB0aGF0IGlzIHN0b3JlZCBpbmRlcGVuZGVudGx5XG5cdFx0Zm9yIChpID0gMDsgaSA8IG1ldGEucy5sZW5ndGg7IGkrKykge1xuXHRcdFx0b2JqLnNlZ21lbnRzLnB1c2goe1xuXHRcdFx0XHRtaW46IG1ldGEuc1tpXVsxXSxcblx0XHRcdFx0bWF4OiBtZXRhLnNbaV1bMl0sXG5cdFx0XHRcdHRhZzogbmFtZSArIFwiX1wiICsgbWV0YS5zW2ldWzBdLFxuXHRcdFx0XHRsb2FkZWQ6IGZhbHNlLFxuXHRcdFx0XHRwOiBudWxsXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblxuXHQvLyBmaW5kIG91dCB0aGUga2V5IGluZm8gZm9yIHRoaXMgdGFibGVcblx0aWYgKG1ldGEuaGFzT3duUHJvcGVydHkoXCJrXCIpKSB7XG5cdFx0a2V5YXJyID0gbWV0YS5rLnNwbGl0KFwiOlwiKTtcblx0XHRvYmoua2V5bmFtZSA9IGtleWFyci5zaGlmdCgpO1xuXHRcdGZvciAoaSA9IDA7IGkgPCBrZXlhcnIubGVuZ3RoOyBpKyspIG9iai5zdWJrZXlzLnB1c2goa2V5YXJyW2ldKTtcblx0fVxuXG5cdC8vIGFkZCBrZXlzIHRvIHRoZSBjb2x1bW4gZGVmaW5pdGlvblxuXHRpZiAob2JqLmtleW5hbWUpIG9iai5jb2x1bW5zLnB1c2gob2JqLmtleW5hbWUpO1xuXHRlbHNlIG9iai5jb2x1bW5zLnB1c2goXCJpbmRleFwiKTtcblx0Zm9yIChpID0gMDsgaSA8IG9iai5zdWJrZXlzLmxlbmd0aDsgaSsrKSB7XG5cdFx0b2JqLmNvbHVtbnMucHVzaChvYmouc3Via2V5c1tpXSk7XG5cdH1cblxuXHQvLyBhZGQgbWV0YSBjb2x1bW5zIHRvIGNvbHVtbiBkZWZpbml0aW9uXG5cdGlmIChtZXRhLmhhc093blByb3BlcnR5KFwiY1wiKSkge1xuXHRcdGZvciAoaSA9IDA7IGkgPCBtZXRhLmMubGVuZ3RoOyBpKyspIG9iai5jb2x1bW5zLnB1c2gobWV0YS5jW2ldKTtcblx0fVxuXG5cdC8vIGNyZWF0ZSBhIHJldmVyc2UgbG9va3VwIG1hcCBmb3IgY29sdW1uc1xuXHRmb3IgKGkgPSAwOyBpIDwgb2JqLmNvbHVtbnMubGVuZ3RoOyBpKyspIG9iai5jb2xtYXBbb2JqLmNvbHVtbnNbaV1dID0gaTtcblx0b2JqLmNvbG1hcC5pbmRleCA9IDA7XG5cdG9iai5jID0gb2JqLmNvbG1hcDtcblxuXHQvLyBncmFiIHRoZSBjb2xtZXRhIGV4dHJhIGluZm9cblx0aWYgKG1ldGEuaGFzT3duUHJvcGVydHkoXCJtXCIpKSB7XG5cdFx0ZXh0ZW5kKHRydWUsIG9iai5jb2xtZXRhLCBtZXRhLm0pO1xuXHR9XG5cblx0Ly8gZ3JhYiB0aGUgbGVuZ3RoXG5cdGlmIChtZXRhLmhhc093blByb3BlcnR5KFwibFwiKSkge1xuXHRcdG9iai5sZW5ndGggPSBtZXRhLmw7XG5cdH1cblxuXHRyZXR1cm4gb2JqO1xufTtcblxuLy8gZ2V0IHRoZSBlbnRyeSBmb3IgdGhlIGtleSBwcm92aWRlZDsgYWxsIGtleXMgbXVzdCBiZSBudW1lcmljIHZhbHVlcyBmb3Igc2VnbWVudGF0aW9uXG5QLkdldEVudHJ5ID0gZnVuY3Rpb24oa2V5KSB7XG5cdHZhciBpLFxuXHRcdG5rZXksXG5cdFx0c2tleTtcblxuXHQvLyBnZXQgYSBndWFyYW50ZWVkIG51bWVyaWMgYW5kIGd1YXJhbnRlZWQgc3RyaW5nIHZlcnNpb24gb2YgdGhlIGtleTsgbnVtZXJpY1xuXHQvLyBpcyBmb3Igc2VnbWVudCBjb21wYXJpc29uLCBzdHJpbmcgaXMgZm9yIG9iamVjdCBwcm9wZXJ0eSBsb29rdXBcblx0bmtleSA9IHBhcnNlSW50KGtleSwgMTApO1xuXHRpZiAoaXNOYU4obmtleSkpIHJldHVybiBudWxsO1xuXHRza2V5ID0gbmtleS50b1N0cmluZygxMCk7XG5cdGlmICh0aGlzLmRhdGEuaGFzT3duUHJvcGVydHkoc2tleSkpIHJldHVybiB0aGlzLmRhdGFbc2tleV07XG5cblx0Ly8gaWYgd2UgZG9uJ3QgaGF2ZSB0aGlzIGtleSwgZGV0ZXJtaW5lIGlmIHdlIG91Z2h0IHRvIGJ5IG5vd1xuXHRmb3IgKGkgPSAwOyBpIDwgdGhpcy5zZWdtZW50cy5sZW5ndGg7IGkrKykge1xuXHRcdGlmIChua2V5ID49IHRoaXMuc2VnbWVudHNbaV0ubWluICYmIChua2V5IDw9IHRoaXMuc2VnbWVudHNbaV0ubWF4IHx8IHRoaXMuc2VnbWVudHNbaV0ubWF4ID09IC0xKSkge1xuXHRcdFx0aWYgKHRoaXMuc2VnbWVudHNbaV0ubG9hZGVkKSByZXR1cm4gbnVsbDsgLy8gdGhlIGtleSBzaG91bGQgYmUgaW4gdGhpcyBzZWdtZW50XG5cdFx0XHRlbHNlIHJldHVybiBmYWxzZTsgLy8gdGhlIHNlZ21lbnQgaXNuJ3QgbG9hZGVkIHlldFxuXHRcdH1cblx0fVxuXG5cdHJldHVybiBudWxsO1xufTtcblxuLy8gZ2V0IHRoZSB2YWx1ZSBmb3IgdGhlIGtleSAob3IgZW50cnkgYXJyYXkpIGFuZCBjb2x1bW4gcHJvdmlkZWRcblAuR2V0VmFsdWUgPSBmdW5jdGlvbihrZXksIGNvbCkge1xuXHR2YXIgZW50cnk7XG5cdGlmIChrZXkgaW5zdGFuY2VvZiBBcnJheSkgZW50cnkgPSBrZXk7XG5cdGVsc2UgZW50cnkgPSB0aGlzLkdldEVudHJ5KGtleSk7XG5cdGlmIChlbnRyeSA9PT0gbnVsbCB8fCBlbnRyeSA9PT0gZmFsc2UpIHJldHVybiBlbnRyeTtcblx0aWYgKGlzTmFOKGNvbCkpIHtcblx0XHRpZiAoIXRoaXMuY29sbWFwLmhhc093blByb3BlcnR5KGNvbCkpIHJldHVybiBudWxsO1xuXHRcdGNvbCA9IHRoaXMuY29sbWFwW2NvbF07XG5cdH1cblx0cmV0dXJuIGVudHJ5W2NvbF07XG59O1xuXG5mdW5jdGlvbiBVbnNoaWZ0SW5kZXhlcyhkYXRhLCBpbmRleGVzKSB7XG5cdHZhciBrZXksIGk7XG5cdGZvciAoa2V5IGluIGRhdGEpIHtcblx0XHRpZiAoIWRhdGEuaGFzT3duUHJvcGVydHkoa2V5KSkgcmV0dXJuO1xuXHRcdGlmICghZGF0YVtrZXldKSByZXR1cm47XG5cdFx0aW5kZXhlcy5wdXNoKHBhcnNlSW50KGtleSwgMTApKTtcblx0XHRpZiAoZGF0YVtrZXldIGluc3RhbmNlb2YgQXJyYXkpIHtcblx0XHRcdGZvciAoaSA9IGluZGV4ZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdFx0ZGF0YVtrZXldLnVuc2hpZnQoaW5kZXhlc1tpXSk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIFVuc2hpZnRJbmRleGVzKGRhdGFba2V5XSwgaW5kZXhlcyk7XG5cdFx0aW5kZXhlcy5wb3AoKTtcblx0fVxufVxuXG5mdW5jdGlvbiBTZWdMb2FkRG9uZShyZXMsIHJlaiwgdGFnLCBkYXRhLCBkb25lLCBjdHgsIHByb2dyZXNzKSB7XG5cdHZhciBpO1xuXHRkb25lLmhhcysrO1xuXHRmb3IgKGkgPSAwOyBpIDwgdGhpcy5zZWdtZW50cy5sZW5ndGg7IGkrKykge1xuXHRcdGlmICh0aGlzLnNlZ21lbnRzW2ldLnRhZyAhPSB0YWcpIGNvbnRpbnVlO1xuXHRcdGlmIChkYXRhLnRhYmxlcy5oYXNPd25Qcm9wZXJ0eSh0aGlzLm5hbWUpICYmIGRhdGEudGFibGVzW3RoaXMubmFtZV0uaGFzT3duUHJvcGVydHkoXCJkXCIpKSB7XG5cdFx0XHRpZiAoIWRhdGEudGFibGVzW3RoaXMubmFtZV0uaGFzT3duUHJvcGVydHkoXCJVXCIpKSB7XG5cdFx0XHRcdC8vIHB1dCB0aGUgaW5kZXhlcyBpbnRvIHRoZSBmaXJzdCBjb2x1bW5zIG9mIGV2ZXJ5IHJvd1xuXHRcdFx0XHRVbnNoaWZ0SW5kZXhlcyhkYXRhLnRhYmxlc1t0aGlzLm5hbWVdLmQsIFtdKTtcblx0XHRcdFx0ZGF0YS50YWJsZXNbdGhpcy5uYW1lXS5VID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdGV4dGVuZCh0aGlzLmRhdGEsIGRhdGEudGFibGVzW3RoaXMubmFtZV0uZCk7XG5cdFx0XHRpZiAoZGF0YS50YWJsZXNbdGhpcy5uYW1lXS5oYXNPd25Qcm9wZXJ0eShcIkxcIikpIHtcblx0XHRcdFx0dGhpcy5sb2FkZWQgKz0gZGF0YS50YWJsZXNbdGhpcy5uYW1lXS5MO1xuXHRcdFx0fSBlbHNlIGlmIChkb25lLm5lZWRzID09IDEpIHtcblx0XHRcdFx0dGhpcy5sb2FkZWQgPSB0aGlzLmxlbmd0aDtcblx0XHRcdH1cblx0XHRcdHRoaXMuc2VnbWVudHNbaV0ubG9hZGVkID0gdHJ1ZTtcblx0XHR9XG5cdFx0YnJlYWs7XG5cdH1cblx0aWYgKHByb2dyZXNzICE9PSBudWxsKSBwcm9ncmVzcyh7XG5cdFx0Y29udGV4dDogY3R4LFxuXHRcdHRhYmxlOiB0aGlzLFxuXHRcdGhhczogZG9uZS5oYXMsXG5cdFx0bmVlZHM6IGRvbmUubmVlZHNcblx0fSk7XG5cdGlmIChkb25lLmhhcyA+PSBkb25lLm5lZWRzKSByZXMoe1xuXHRcdGNvbnRleHQ6IGN0eCxcblx0XHR0YWJsZTogdGhpc1xuXHR9KTtcbn1cblxuLy8gbG9hZCBkYXRhIGZvciB0aGlzIHRhYmxlOyByZXR1cm5zIGEgZGVmZXJyZWQgcHJvbWlzZSBvYmplY3QgYXMgdGhpcyBpcyBhbiBhc3luYyB0aGluZ1xuLy8gaWYga2V5IGlzIHByb3ZpZGVkLCBsb2FkcyBPTkxZIHRoZSBzZWdtZW50IGNvbnRhaW5pbmcgdGhhdCBrZXlcblAuTG9hZCA9IGZ1bmN0aW9uKG9wdHMpIHtcblx0dmFyIHNlbGYgPSB0aGlzLFxuXHRcdGFsbF9uZWVkcyA9IFtdLFxuXHRcdG5rZXksXG5cdFx0c2tleSxcblx0XHRpLFxuXHRcdHNlZ21lbnQsXG5cdFx0byA9IHtcblx0XHRcdGNvbnRleHQ6IG51bGwsXG5cdFx0XHRrZXk6IG51bGwsXG5cdFx0XHRwcm9ncmVzczogbnVsbFxuXHRcdH07XG5cdGV4dGVuZChvLCBvcHRzKTtcblxuXHQvLyBmaWd1cmUgb3V0IHdoaWNoIHNlZ21lbnRzIG5lZWQgbG9hZGluZ1xuXHRpZiAoby5rZXkgPT09IG51bGwpIHtcblx0XHQvLyBubyBrZXkgc3BlY2lmaWVkOyBsb2FkIGFsbCBzZWdtZW50c1xuXHRcdGZvciAoaSA9IDA7IGkgPCB0aGlzLnNlZ21lbnRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRpZiAoIXRoaXMuc2VnbWVudHNbaV0ubG9hZGVkKSB7XG5cdFx0XHRcdC8vIHRoaXMgc2VnbWVudCBub3QgeWV0IGxvYWRlZFxuXHRcdFx0XHRhbGxfbmVlZHMucHVzaChpKTtcblx0XHRcdH1cblx0XHR9XG5cdH0gZWxzZSB7XG5cdFx0Ly8gZGV0ZXJtaW5lIHdoaWNoIHNlZ21lbnQgdGhlIGtleSBpcyBpblxuXHRcdG5rZXkgPSBwYXJzZUludChvLmtleSwgMTApO1xuXHRcdGlmIChpc05hTihua2V5KSkge1xuXHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcImludmFsaWQga2V5OyBub3QgbnVtZXJpY1wiKSk7XG5cdFx0fVxuXHRcdHNrZXkgPSBua2V5LnRvU3RyaW5nKDEwKTtcblx0XHRzZWdtZW50ID0gLTE7XG5cdFx0Zm9yIChpID0gMDsgaSA8IHRoaXMuc2VnbWVudHMubGVuZ3RoOyBpKyspIHtcblx0XHRcdGlmIChua2V5ID49IHRoaXMuc2VnbWVudHNbaV0ubWluICYmIChua2V5IDw9IHRoaXMuc2VnbWVudHNbaV0ubWF4IHx8IHRoaXMuc2VnbWVudHNbaV0ubWF4ID09IC0xKSkge1xuXHRcdFx0XHQvLyB0aGUga2V5IHNob3VsZCBiZSBpbiB0aGlzIHNlZ21lbnRcblx0XHRcdFx0c2VnbWVudCA9IGk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmIChzZWdtZW50ID09PSAtMSkge1xuXHRcdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBFcnJvcihcImludmFsaWQga2V5OyBubyBzZWdtZW50IGNvbnRhaW5zIGl0XCIpKTtcblx0XHR9XG5cdFx0aWYgKCF0aGlzLnNlZ21lbnRzW3NlZ21lbnRdLmxvYWRlZCkge1xuXHRcdFx0YWxsX25lZWRzLnB1c2goc2VnbWVudCk7XG5cdFx0fVxuXHR9XG5cblx0aWYgKGFsbF9uZWVkcy5sZW5ndGggPCAxKSB7XG5cdFx0Ly8gYWxsIHJlcXVpcmVkIGRhdGEgYWxyZWFkeSBsb2FkZWRcblx0XHRyZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHtcblx0XHRcdGNvbnRleHQ6IG8uY29udGV4dCxcblx0XHRcdHRhYmxlOiB0aGlzXG5cdFx0fSk7XG5cdH1cblxuXHRyZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24ocmVzLCByZWopIHtcblx0XHR2YXIgZG9uZSA9IHtcblx0XHRcdG5lZWRzOiBhbGxfbmVlZHMubGVuZ3RoLFxuXHRcdFx0aGFzOiAwXG5cdFx0fTtcblx0XHR2YXIgdGhlbkRvbmUgPSBmdW5jdGlvbihhcmcpIHtcblx0XHRcdFNlZ0xvYWREb25lLmFwcGx5KHNlbGYsIFtyZXMsIHJlaiwgYXJnLnRhZywgYXJnLmRhdGEsIGRvbmUsIG8uY29udGV4dCwgby5wcm9ncmVzc10pO1xuXHRcdH07XG5cdFx0Zm9yIChpID0gMDsgaSA8IGFsbF9uZWVkcy5sZW5ndGg7IGkrKykge1xuXHRcdFx0c2VnbWVudCA9IHNlbGYuc2VnbWVudHNbYWxsX25lZWRzW2ldXTtcblx0XHRcdGlmICghc2VnbWVudC5wKSB7XG5cdFx0XHRcdC8vIHRoaXMgc2VnbWVudCBub3QgcGVuZGluZyBsb2FkXG5cdFx0XHRcdHNlZ21lbnQucCA9IHNlbGYuc3JjLkxvYWRUYWcoc2VnbWVudC50YWcpO1xuXHRcdFx0fVxuXHRcdFx0c2VnbWVudC5wLnRoZW4odGhlbkRvbmUpO1xuXHRcdH1cblx0fSk7XG59O1xuXG5QLkNvbEl0ZXIgPSBmdW5jdGlvbihjb2xuYW1lKSB7XG5cdHZhciBjb2xudW07XG5cdGlmICh0aGlzLmNvbG1hcC5oYXNPd25Qcm9wZXJ0eShjb2xuYW1lKSkge1xuXHRcdGNvbG51bSA9IHRoaXMuY29sbWFwW2NvbG5hbWVdO1xuXHRcdHJldHVybiBmdW5jdGlvbihlKSB7XG5cdFx0XHRyZXR1cm4gZVtjb2xudW1dO1xuXHRcdH07XG5cdH0gZWxzZSByZXR1cm4gZnVuY3Rpb24oKSB7XG5cdFx0cmV0dXJuIHVuZGVmaW5lZDtcblx0fTtcbn07XG5cblAuQ29sUHJlZCA9IGZ1bmN0aW9uKGNvbG5hbWUsIGNvbXBhcmUsIHZhbHVlKSB7XG5cdHZhciBjb2xudW07XG5cdGlmICh0aGlzLmNvbG1hcC5oYXNPd25Qcm9wZXJ0eShjb2xuYW1lKSkge1xuXHRcdGNvbG51bSA9IHRoaXMuY29sbWFwW2NvbG5hbWVdO1xuXHRcdGlmIChjb21wYXJlID09IFwiPT1cIiB8fCBjb21wYXJlID09IFwiZXFcIikgcmV0dXJuIGZ1bmN0aW9uKGUpIHtcblx0XHRcdHJldHVybiBlW2NvbG51bV0gPT0gdmFsdWU7XG5cdFx0fTtcblx0XHRpZiAoY29tcGFyZSA9PSBcIiE9XCIgfHwgY29tcGFyZSA9PSBcIm5lXCIpIHJldHVybiBmdW5jdGlvbihlKSB7XG5cdFx0XHRyZXR1cm4gZVtjb2xudW1dICE9IHZhbHVlO1xuXHRcdH07XG5cdFx0aWYgKGNvbXBhcmUgPT0gXCI9PT1cIiB8fCBjb21wYXJlID09IFwic2VxXCIpIHJldHVybiBmdW5jdGlvbihlKSB7XG5cdFx0XHRyZXR1cm4gZVtjb2xudW1dID09PSB2YWx1ZTtcblx0XHR9O1xuXHRcdGlmIChjb21wYXJlID09IFwiIT09XCIgfHwgY29tcGFyZSA9PSBcInNuZVwiKSByZXR1cm4gZnVuY3Rpb24oZSkge1xuXHRcdFx0cmV0dXJuIGVbY29sbnVtXSAhPT0gdmFsdWU7XG5cdFx0fTtcblx0XHRlbHNlIGlmIChjb21wYXJlID09IFwiPlwiIHx8IGNvbXBhcmUgPT0gXCJndFwiKSByZXR1cm4gZnVuY3Rpb24oZSkge1xuXHRcdFx0cmV0dXJuIGVbY29sbnVtXSA+IHZhbHVlO1xuXHRcdH07XG5cdFx0ZWxzZSBpZiAoY29tcGFyZSA9PSBcIj49XCIgfHwgY29tcGFyZSA9PSBcImd0ZVwiKSByZXR1cm4gZnVuY3Rpb24oZSkge1xuXHRcdFx0cmV0dXJuIGVbY29sbnVtXSA+PSB2YWx1ZTtcblx0XHR9O1xuXHRcdGVsc2UgaWYgKGNvbXBhcmUgPT0gXCI8XCIgfHwgY29tcGFyZSA9PSBcImx0XCIpIHJldHVybiBmdW5jdGlvbihlKSB7XG5cdFx0XHRyZXR1cm4gZVtjb2xudW1dIDwgdmFsdWU7XG5cdFx0fTtcblx0XHRlbHNlIGlmIChjb21wYXJlID09IFwiPD1cIiB8fCBjb21wYXJlID09IFwibHRlXCIpIHJldHVybiBmdW5jdGlvbihlKSB7XG5cdFx0XHRyZXR1cm4gZVtjb2xudW1dIDwgdmFsdWU7XG5cdFx0fTtcblx0fSBlbHNlIHJldHVybiBmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG59O1xuIiwiLy8gdmFyIFV0aWxzID0gcmVxdWlyZSgnLi9VdGlscycpO1xuXG5leHBvcnRzLlNvdXJjZSA9IHJlcXVpcmUoXCIuL1NERC5Tb3VyY2VcIik7XG5leHBvcnRzLlNvdXJjZS5qc29uID0gcmVxdWlyZShcIi4vU0RELlNvdXJjZS5qc29uXCIpO1xuZXhwb3J0cy5UYWJsZSA9IHJlcXVpcmUoXCIuL1NERC5UYWJsZVwiKTtcblxuLy8gY3JlYXRlIGEgbmV3IGRhdGEgc291cmNlIG9mIHRoZSB0eXBlIHNwZWNpZmllZCB3aXRoIHRoZSBjb25maWcgcHJvdmlkZWQ7XG4vLyBFVkVvai5kYXRhLlNvdXJjZS48dHlwZT4gaGFuZGxlcyB0aGUgaW1wbGVtZW50YXRpb24gZGV0YWlsc1xuZXhwb3J0cy5DcmVhdGUgPSBmdW5jdGlvbih0eXBlLCBjb25maWcpIHtcblx0aWYgKHR5cGVvZiBleHBvcnRzLlNvdXJjZVt0eXBlXSA9PT0gXCJ1bmRlZmluZWRcIiB8fCB0eXBlb2YgZXhwb3J0cy5Tb3VyY2VbdHlwZV0uQ3JlYXRlICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuXHRyZXR1cm4gZXhwb3J0cy5Tb3VyY2VbdHlwZV0uQ3JlYXRlKGNvbmZpZyk7XG59O1xuIiwiLyogZ2xvYmFsIGpRdWVyeTogZmFsc2UgKi9cbnZhciBQcm9taXNlID0gcmVxdWlyZShcIi4vUHJvbWlzZVwiKTtcblxuZXhwb3J0cy5pc0Jyb3dzZXIgPSB0eXBlb2Yod2luZG93KSAhPT0gXCJ1bmRlZmluZWRcIjtcblxudmFyIEYgPSBmdW5jdGlvbigpIHt9O1xuXG5leHBvcnRzLmNyZWF0ZSA9ICh0eXBlb2YgT2JqZWN0LmNyZWF0ZSA9PT0gXCJmdW5jdGlvblwiKSA/XG5cdE9iamVjdC5jcmVhdGUgOlxuXHRmdW5jdGlvbihvKSB7XG5cdFx0Ly8gb2JqZWN0IGNyZWF0ZSBwb2x5ZmlsbCAoaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvT2JqZWN0L2NyZWF0ZSlcblx0XHRpZiAoYXJndW1lbnRzLmxlbmd0aCA+IDEpIHRocm93IEVycm9yKFwiU2Vjb25kIGFyZ3VtZW50IG5vdCBzdXBwb3J0ZWRcIik7XG5cdFx0aWYgKG8gPT09IG51bGwpIHRocm93IEVycm9yKFwiQ2Fubm90IHNldCBhIG51bGwgW1tQcm90b3R5cGVdXVwiKTtcblx0XHRpZiAodHlwZW9mKG8pICE9PSBcIm9iamVjdFwiKSB0aHJvdyBUeXBlRXJyb3IoXCJBcmd1bWVudCBtdXN0IGJlIGFuIG9iamVjdFwiKTtcblx0XHRGLnByb3RvdHlwZSA9IG87XG5cdFx0cmV0dXJuIG5ldyBGKCk7XG5cdH07XG5cbmV4cG9ydHMuRm9ybWF0TnVtID0gZnVuY3Rpb24odmFsLCBmaXhlZCkge1xuXHR2YXIgc3RyaW5neSA9IFtdLFxuXHRcdGJhc2UgPSBTdHJpbmcoTWF0aC5mbG9vcih2YWwpKSxcblx0XHRrID0gLTEsXG5cdFx0aSA9IDAsXG5cdFx0ZGVjaW1hbHM7XG5cblx0Zml4ZWQgPSBmaXhlZCB8fCAwO1xuXG5cdGZvciAoaSA9IGJhc2UubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRpZiAoayAlIDMgPT09IDApIHtcblx0XHRcdGsgPSAxO1xuXHRcdFx0c3RyaW5neS5wdXNoKFwiLFwiKTtcblx0XHR9IGVsc2UgaWYgKGsgPT0gLTEpIHtcblx0XHRcdGsgPSAxO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRrKys7XG5cdFx0fVxuXHRcdHN0cmluZ3kucHVzaChiYXNlLmNoYXJBdChpKSk7XG5cdH1cblx0YmFzZSA9IFwiXCI7XG5cdGZvciAoaSA9IHN0cmluZ3kubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRiYXNlID0gYmFzZS5jb25jYXQoc3RyaW5neVtpXSk7XG5cdH1cblxuXHRpZiAoZml4ZWQgPiAwKSB7XG5cdFx0ZGVjaW1hbHMgPSB2YWwudG9GaXhlZChmaXhlZCk7XG5cdFx0YmFzZSArPSBkZWNpbWFscy5zdWJzdHJpbmcoZGVjaW1hbHMubGVuZ3RoIC0gZml4ZWQgLSAxKTtcblx0fVxuXG5cdHJldHVybiBiYXNlO1xufTtcblxudmFyIGFqYXhQID0gZnVuY3Rpb24odXJsLCBzZXR0aW5ncywgY2IpIHtcblx0alF1ZXJ5LmFqYXgodXJsLCBzZXR0aW5ncykuZG9uZShmdW5jdGlvbihkYXRhLCBzdGF0dXMsIGpxeGhyKSB7XG5cdFx0Y2IobnVsbCwgZGF0YSk7XG5cdH0pLmZhaWwoZnVuY3Rpb24oanF4aHIsIHN0YXR1cywgZXJyb3IpIHtcblx0XHRjYihlcnJvciwgbnVsbCk7XG5cdH0pO1xufTtcbmV4cG9ydHMuYWpheFAgPSBQcm9taXNlLnByb21pc2lmeShhamF4UCk7XG4iLCJ2YXIgZXh0ZW5kID0gcmVxdWlyZShcIm5vZGUuZXh0ZW5kXCIpO1xudmFyIFV0aWxzID0gcmVxdWlyZShcIi4vVXRpbHNcIik7XG5cbnZhciBQID0gZXhwb3J0cy5QID0ge307IC8vIHB1YmxpYyBtZXRob2RzXG5cbmV4cG9ydHMuRCA9IHtcblx0SUQ6IG51bGwsXG5cdG5hbWU6IG51bGwsXG5cdHJlZ2lvbklEOiBudWxsLFxuXHRjb25zdGVsbGF0aW9uSUQ6IG51bGwsXG5cdHBvczoge1xuXHRcdHg6IG51bGwsXG5cdFx0eTogbnVsbCxcblx0XHR6OiBudWxsXG5cdH0sXG5cdHBvc01heDoge1xuXHRcdHg6IG51bGwsXG5cdFx0eTogbnVsbCxcblx0XHR6OiBudWxsXG5cdH0sXG5cdHBvc01pbjoge1xuXHRcdHg6IG51bGwsXG5cdFx0eTogbnVsbCxcblx0XHR6OiBudWxsXG5cdH0sXG5cdGJvcmRlcjogbnVsbCxcblx0ZnJpbmdlOiBudWxsLFxuXHRjb3JyaWRvcjogbnVsbCxcblx0aHViOiBudWxsLFxuXHRpbnRlcm5hdGlvbmFsOiBudWxsLFxuXHRyZWdpb25hbDogbnVsbCxcblx0Y29uc3RlbGxhdGlvbjogbnVsbCxcblx0Y29udGlndW91czogbnVsbCxcblx0c2VjdXJpdHk6IG51bGwsXG5cdHNlYzogbnVsbCxcblx0cmFkaXVzOiBudWxsLFxuXHRzZWN1cml0eUNsYXNzOiBudWxsLFxuXHR3b3JtaG9sZUNsYXNzSUQ6IG51bGwsXG5cdHN0YXRpb25Db3VudDogbnVsbCxcblx0anVtcHM6IG51bGxcbn07XG5leHBvcnRzLkNyZWF0ZSA9IGZ1bmN0aW9uKHRibCwgSUQpIHtcblx0dmFyIG9iaixcblx0XHRzeXMsXG5cdFx0Y29sLFxuXHRcdG5JRDtcblxuXHRuSUQgPSBwYXJzZUludChJRCwgMTApO1xuXG5cdHN5cyA9IHRibC5HZXRFbnRyeShuSUQpO1xuXHRpZiAoIXN5cykgcmV0dXJuIG51bGw7XG5cdG9iaiA9IFV0aWxzLmNyZWF0ZShQKTtcblx0ZXh0ZW5kKHRydWUsIG9iaiwgZXhwb3J0cy5EKTtcblx0Y29sID0gdGJsLmNvbG1hcDtcblxuXHRvYmouSUQgPSBuSUQ7XG5cdG9iai5uYW1lID0gc3lzW2NvbC5zb2xhclN5c3RlbU5hbWVdO1xuXHRvYmoucmVnaW9uSUQgPSBzeXNbY29sLnJlZ2lvbklEXTtcblx0b2JqLmNvbnN0ZWxsYXRpb25JRCA9IHN5c1tjb2wuY29uc3RlbGxhdGlvbklEXTtcblx0b2JqLnBvcyA9IHtcblx0XHR4OiBzeXNbY29sLmNlbnRlcl1bMF0sXG5cdFx0eTogc3lzW2NvbC5jZW50ZXJdWzFdLFxuXHRcdHo6IHN5c1tjb2wuY2VudGVyXVsyXVxuXHR9O1xuXHRvYmoucG9zTWluID0ge1xuXHRcdHg6IHN5c1tjb2wubWluXVswXSxcblx0XHR5OiBzeXNbY29sLm1pbl1bMV0sXG5cdFx0ejogc3lzW2NvbC5taW5dWzJdXG5cdH07XG5cdG9iai5wb3NNYXggPSB7XG5cdFx0eDogc3lzW2NvbC5tYXhdWzBdLFxuXHRcdHk6IHN5c1tjb2wubWF4XVsxXSxcblx0XHR6OiBzeXNbY29sLm1heF1bMl1cblx0fTtcblx0b2JqLmJvcmRlciA9IHN5c1tjb2wuYm9yZGVyXTtcblx0b2JqLmZyaW5nZSA9IHN5c1tjb2wuZnJpbmdlXTtcblx0b2JqLmNvcnJpZG9yID0gc3lzW2NvbC5jb3JyaWRvcl07XG5cdG9iai5odWIgPSBzeXNbY29sLmh1Yl07XG5cdG9iai5pbnRlcm5hdGlvbmFsID0gc3lzW2NvbC5pbnRlcm5hdGlvbmFsXTtcblx0b2JqLnJlZ2lvbmFsID0gc3lzW2NvbC5yZWdpb25hbF07XG5cdG9iai5jb25zdGVsbGF0aW9uID0gc3lzW2NvbC5jb25zdGVsbGF0aW9uXTtcblx0b2JqLmNvbnRpZ3VvdXMgPSBzeXNbY29sLmNvbnRpZ3VvdXNdO1xuXHRvYmouc2VjdXJpdHkgPSBzeXNbY29sLnNlY3VyaXR5XTtcblx0b2JqLnNlYyA9IChvYmouc2VjdXJpdHkgPiAwKSA/IG9iai5zZWN1cml0eS50b0ZpeGVkKDEpIDogXCIwLjBcIjtcblx0b2JqLnJhZGl1cyA9IHN5c1tjb2wucmFkaXVzXTtcblx0b2JqLnNlY3VyaXR5Q2xhc3MgPSBzeXNbY29sLnNlY3VyaXR5Q2xhc3NdO1xuXHRvYmoud29ybWhvbGVDbGFzc0lEID0gc3lzW2NvbC53b3JtaG9sZUNsYXNzSURdO1xuXHRvYmouc3RhdGlvbkNvdW50ID0gKHN5c1tjb2wuc3RhdGlvbkNvdW50XSkgPyBzeXNbY29sLnN0YXRpb25Db3VudF0gOiAwO1xuXHRvYmouanVtcHMgPSBzeXNbY29sLmp1bXBzXTtcblxuXHRyZXR1cm4gb2JqO1xufTtcbiIsInZhciBleHRlbmQgPSByZXF1aXJlKFwibm9kZS5leHRlbmRcIik7XG52YXIgVXRpbHMgPSByZXF1aXJlKFwiLi9VdGlsc1wiKTtcblxudmFyIFAgPSBleHBvcnRzLlAgPSB7fTsgLy8gcHVibGljIG1ldGhvZHNcbmV4cG9ydHMuRCA9IHtcblx0Ly8gZGVmYXVsdCBvYmplY3QgcHJvcGVydGllc1xuXHRjdXJpZHg6IDAsXG5cdG1hcDogbnVsbCxcblx0a2V5c2V0OiBbXVxufTtcbmV4cG9ydHMuQ3JlYXRlID0gZnVuY3Rpb24obWFwKSB7XG5cdHZhciBvYmosXG5cdFx0a2V5LFxuXHRcdHRibDtcblxuXHRvYmogPSBVdGlscy5jcmVhdGUoUCk7XG5cdGV4dGVuZCh0cnVlLCBvYmosIGV4cG9ydHMuRCk7XG5cdG9iai5tYXAgPSBtYXA7XG5cdHRibCA9IG1hcC50YWJsZXNbXCJtYXBcIiArIG1hcC5zcGFjZSArIFwiU29sYXJTeXN0ZW1zXCJdLnRibDtcblxuXHRmb3IgKGtleSBpbiB0YmwuZGF0YSkge1xuXHRcdGlmICghdGJsLmRhdGEuaGFzT3duUHJvcGVydHkoa2V5KSkgY29udGludWU7XG5cdFx0b2JqLmtleXNldC5wdXNoKGtleSk7XG5cdH1cblxuXHRyZXR1cm4gb2JqO1xufTtcblxuUC5IYXNOZXh0ID0gZnVuY3Rpb24oKSB7XG5cdGlmICh0aGlzLmN1cmlkeCA8IHRoaXMua2V5c2V0Lmxlbmd0aCkgcmV0dXJuIHRydWU7XG59O1xuXG5QLk5leHQgPSBmdW5jdGlvbigpIHtcblx0cmV0dXJuIHRoaXMubWFwLkdldFN5c3RlbSh7XG5cdFx0aWQ6IHRoaXMua2V5c2V0W3RoaXMuY3VyaWR4KytdXG5cdH0pO1xufTtcbiIsInZhciBleHRlbmQgPSByZXF1aXJlKFwibm9kZS5leHRlbmRcIiksXG5cdENvbnN0ID0gcmVxdWlyZShcIi4vQ29uc3RcIiksXG5cdFV0aWxzID0gcmVxdWlyZShcIi4vVXRpbHNcIiksXG5cdFN5c3RlbSA9IHJlcXVpcmUoXCIuL21hcC5TeXN0ZW1cIiksXG5cdFN5c3RlbUl0ZXIgPSByZXF1aXJlKFwiLi9tYXAuU3lzdGVtSXRlclwiKSxcblx0UHJvbWlzZSA9IHJlcXVpcmUoXCIuL1Byb21pc2VcIik7XG5cbnZhciBQID0gZXhwb3J0cy5QID0ge307IC8vIHB1YmxpYyBtZXRob2RzIGZvciB0aGlzIGNsYXNzXG5cbmV4cG9ydHMuRCA9IHtcblx0Ly8gZGVmYXVsdCBwcm9wZXJ0aWVzIGZvciBuZXcgaW5zdGFuY2VzXG5cdHNyYzogbnVsbCxcblx0dGFibGVzOiB7fSxcblx0c3lzTmFtZU1hcDoge30sXG5cdHN5c05hbWVzOiBbXSxcblx0cm91dGVHcmFwaDoge30sXG5cdHNwYWNlOiBudWxsLFxuXHRsb2FkZWQ6IGZhbHNlLFxuXHRsb2FkaW5nUDogbnVsbCxcblx0Yzoge1xuXHRcdGp1bXBzOiBmYWxzZSxcblx0XHRwbGFuZXRzOiBmYWxzZSxcblx0XHRtb29uczogZmFsc2UsXG5cdFx0YmVsdHM6IGZhbHNlLFxuXHRcdGdhdGVzOiBmYWxzZSxcblx0XHRzdGFyczogZmFsc2UsXG5cdFx0b2JqZWN0czogZmFsc2UsXG5cdFx0bGFuZG1hcmtzOiBmYWxzZVxuXHR9XG59O1xuXG52YXIgc3lzX2NhY2hlID0gbnVsbDsgLy8gYSBwbGFjZSB0byBwdXQgZ2VuZXJhdGVkIHN5c3RlbXMgc28gd2UgZG9uJ3Qga2VlcCByZS1jcmVhdGluZyB0aGVtXG5cbmV4cG9ydHMuQ3JlYXRlID0gZnVuY3Rpb24oc3JjLCB0eXBlLCBjb25maWcpIHtcblx0aWYgKCFzcmMgfHwgdHlwZW9mIHNyYy5IYXNUYWJsZSAhPSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuXHRpZiAodHlwZSAhPSBcIktcIiAmJiB0eXBlICE9IFwiWFwiICYmIHR5cGUgIT0gXCJKXCIpIHJldHVybiBudWxsO1xuXHR2YXIgb2JqID0gVXRpbHMuY3JlYXRlKFApO1xuXHRleHRlbmQodHJ1ZSwgb2JqLCBleHBvcnRzLkQpO1xuXHRpZiAoY29uZmlnKSBleHRlbmQodHJ1ZSwgb2JqLmMsIGNvbmZpZyk7XG5cdG9iai5zcmMgPSBzcmM7XG5cdG9iai5zcGFjZSA9IHR5cGU7XG5cblx0cmV0dXJuIG9iajtcbn07XG5cbmZ1bmN0aW9uIExvYWREb25lKHJlcywgcmVqLCB0YmwsIGN0eCkge1xuXHR2YXIgaGFzID0gMCxcblx0XHRuZWVkcyA9IDAsXG5cdFx0a2V5O1xuXG5cdGZvciAoa2V5IGluIHRoaXMudGFibGVzKSB7XG5cdFx0aWYgKCF0aGlzLnRhYmxlcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSBjb250aW51ZTtcblx0XHRuZWVkcyArPSB0aGlzLnRhYmxlc1trZXldLnRibC5zZWdtZW50cy5sZW5ndGg7XG5cdFx0aWYgKGtleSA9PSB0YmwubmFtZSkgdGhpcy50YWJsZXNba2V5XS5kb25lID0gdHJ1ZTtcblx0XHRpZiAodGhpcy50YWJsZXNba2V5XS5kb25lKSB7XG5cdFx0XHRoYXMgKz0gdGhpcy50YWJsZXNba2V5XS50Ymwuc2VnbWVudHMubGVuZ3RoO1xuXHRcdH1cblx0fVxuXG5cdGlmIChoYXMgPj0gbmVlZHMpIHtcblx0XHRMb2FkSW5pdC5hcHBseSh0aGlzKTtcblx0XHRyZXMoe1xuXHRcdFx0Y29udGV4dDogY3R4LFxuXHRcdFx0bWFwOiB0aGlzXG5cdFx0fSk7XG5cdH1cbn1cblxuZnVuY3Rpb24gTG9hZFByb2dyZXNzKGFyZywgcHJvZ3Jlc3MpIHtcblx0dmFyIGhhcyA9IDAsXG5cdFx0bmVlZHMgPSAwLFxuXHRcdGtleSxcblx0XHRpO1xuXG5cdGlmIChwcm9ncmVzcyA9PT0gbnVsbCkgcmV0dXJuO1xuXG5cdC8vIGFyZzoge2NvbnRleHQ6IGN0eCwgdGFibGU6IHRoaXMsIGhhczogZG9uZS5oYXMsIG5lZWRzOiBkb25lLm5lZWRzfVxuXHQvLyBpZ25vcmluZyBpbnB1dCBwcm9ncmVzcyBpbmZvIGFuZCBjb3VudGluZyBmaW5pc2hlZCBzZWdtZW50cyBvdXJzZWxmXG5cdGZvciAoa2V5IGluIHRoaXMudGFibGVzKSB7XG5cdFx0aWYgKCF0aGlzLnRhYmxlcy5oYXNPd25Qcm9wZXJ0eShrZXkpKSBjb250aW51ZTtcblx0XHRuZWVkcyArPSB0aGlzLnRhYmxlc1trZXldLnRibC5zZWdtZW50cy5sZW5ndGg7XG5cdFx0Zm9yIChpID0gMDsgaSA8IHRoaXMudGFibGVzW2tleV0udGJsLnNlZ21lbnRzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRpZiAodGhpcy50YWJsZXNba2V5XS50Ymwuc2VnbWVudHNbaV0ubG9hZGVkKSBoYXMrKztcblx0XHR9XG5cdH1cblxuXHRwcm9ncmVzcyh7XG5cdFx0Y29udGV4dDogYXJnLmNvbnRleHQsXG5cdFx0bWFwOiB0aGlzLFxuXHRcdGhhczogaGFzLFxuXHRcdG5lZWRzOiBuZWVkc1xuXHR9KTtcbn1cblAuTG9hZCA9IGZ1bmN0aW9uKG9wdHMpIHtcblx0dmFyIHNlbGYgPSB0aGlzLFxuXHRcdHQgPSB0aGlzLnRhYmxlcyxcblx0XHRvID0ge1xuXHRcdFx0Y29udGV4dDogbnVsbCxcblx0XHRcdHByb2dyZXNzOiBudWxsXG5cdFx0fTtcblx0ZXh0ZW5kKG8sIG9wdHMpO1xuXG5cdGlmICh0aGlzLmxvYWRlZCkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7XG5cdFx0Y29udGV4dDogby5jb250ZXh0LFxuXHRcdG1hcDogdGhpc1xuXHR9KTtcblx0aWYgKHRoaXMubG9hZGluZ1ApIHJldHVybiB0aGlzLmxvYWRpbmdQO1xuXG5cdC8vIHNldHVwIHJlcXVpcmVkIGFuZCBvcHRpb25hbCB0YWJsZXNcblx0dFtcIm1hcFwiICsgdGhpcy5zcGFjZSArIFwiUmVnaW9uc1wiXSA9IGZhbHNlO1xuXHR0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJDb25zdGVsbGF0aW9uc1wiXSA9IGZhbHNlO1xuXHR0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJTb2xhclN5c3RlbXNcIl0gPSBmYWxzZTtcblx0aWYgKHRoaXMuc3BhY2UgPT0gXCJLXCIgfHwgdGhpcy5zcGFjZSA9PSBcIlhcIikge1xuXHRcdGlmICh0aGlzLmMuanVtcHMpIHtcblx0XHRcdHRbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlJlZ2lvbkp1bXBzXCJdID0gZmFsc2U7XG5cdFx0XHR0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJDb25zdGVsbGF0aW9uSnVtcHNcIl0gPSBmYWxzZTtcblx0XHRcdHRbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtSnVtcHNcIl0gPSBmYWxzZTtcblx0XHR9XG5cdFx0aWYgKHRoaXMuYy5iZWx0cykgdFtcIm1hcFwiICsgdGhpcy5zcGFjZSArIFwiQmVsdHNcIl0gPSBmYWxzZTtcblx0XHRpZiAodGhpcy5jLmdhdGVzKSB0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJHYXRlc1wiXSA9IGZhbHNlO1xuXHRcdGlmICh0aGlzLmMubGFuZG1hcmtzKSB0Lm1hcExhbmRtYXJrcyA9IGZhbHNlO1xuXHR9XG5cdGlmICh0aGlzLmMucGxhbmV0cykgdFtcIm1hcFwiICsgdGhpcy5zcGFjZSArIFwiUGxhbmV0c1wiXSA9IGZhbHNlO1xuXHRpZiAodGhpcy5jLm1vb25zKSB0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJNb29uc1wiXSA9IGZhbHNlO1xuXHRpZiAodGhpcy5jLnN0YXJzKSB0W1wibWFwXCIgKyB0aGlzLnNwYWNlICsgXCJTdGFyc1wiXSA9IGZhbHNlO1xuXHRpZiAodGhpcy5jLm9iamVjdHMpIHRbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtT2JqZWN0c1wiXSA9IGZhbHNlO1xuXG5cdHRoaXMubG9hZGluZ1AgPSBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXMsIHJlaikge1xuXHRcdHZhciB0aGVuRG9uZSA9IGZ1bmN0aW9uKGFyZykge1xuXHRcdFx0TG9hZERvbmUuYXBwbHkoc2VsZiwgW3JlcywgcmVqLCBhcmcudGFibGUsIGFyZy5jb250ZXh0XSk7XG5cdFx0fTtcblx0XHR2YXIgcHJvZ3Jlc3NGdW5jID0gbnVsbDtcblx0XHR2YXIga2V5O1xuXHRcdGlmIChvLnByb2dyZXNzICE9PSBudWxsKSB7XG5cdFx0XHRwcm9ncmVzc0Z1bmMgPSBmdW5jdGlvbihhcmcpIHtcblx0XHRcdFx0TG9hZFByb2dyZXNzLmFwcGx5KHNlbGYsIFthcmcsIG8ucHJvZ3Jlc3NdKTtcblx0XHRcdH07XG5cdFx0fVxuXHRcdGZvciAoa2V5IGluIHQpIHtcblx0XHRcdGlmICghdC5oYXNPd25Qcm9wZXJ0eShrZXkpKSBjb250aW51ZTtcblx0XHRcdHRba2V5XSA9IHtcblx0XHRcdFx0dGJsOiBzZWxmLnNyYy5HZXRUYWJsZShrZXkpLFxuXHRcdFx0XHRkb25lOiBmYWxzZVxuXHRcdFx0fTtcblx0XHRcdGlmICghdFtrZXldLnRibCkge1xuXHRcdFx0XHRyZWoobmV3IEVycm9yKFwic291cmNlIGRvZXMgbm90IGNvbnRhaW4gcmVxdWVzdGVkIHRhYmxlOiBcIiArIGtleSkpO1xuXHRcdFx0XHRyZXR1cm4gc2VsZi5sb2FkaW5nUDtcblx0XHRcdH1cblx0XHRcdHRba2V5XS50YmwuTG9hZCh7XG5cdFx0XHRcdGNvbnRleHQ6IG8uY29udGV4dCxcblx0XHRcdFx0cHJvZ3Jlc3M6IHByb2dyZXNzRnVuY1xuXHRcdFx0fSkudGhlbih0aGVuRG9uZSk7XG5cdFx0fVxuXHR9KTtcblxuXHRyZXR1cm4gdGhpcy5sb2FkaW5nUDtcbn07XG5cbmZ1bmN0aW9uIExvYWRJbml0KCkge1xuXHR2YXIgc3lzdGJsID0gdGhpcy50YWJsZXNbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtc1wiXS50YmwsXG5cdFx0Y29sbWFwID0gc3lzdGJsLmNvbG1hcCxcblx0XHRzb2xhclN5c3RlbUlELFxuXHRcdHRvU29sYXJTeXN0ZW1JRCxcblx0XHRzeXN0ZW0sXG5cdFx0aSxcblx0XHRzeXM7XG5cblx0c3lzX2NhY2hlID0ge307XG5cdGZvciAoc29sYXJTeXN0ZW1JRCBpbiBzeXN0YmwuZGF0YSkge1xuXHRcdGlmICghc3lzdGJsLmRhdGEuaGFzT3duUHJvcGVydHkoc29sYXJTeXN0ZW1JRCkpIGNvbnRpbnVlO1xuXHRcdHN5c3RlbSA9IHN5c3RibC5kYXRhW3NvbGFyU3lzdGVtSURdO1xuXHRcdHRoaXMuc3lzTmFtZU1hcFtzeXN0ZW1bY29sbWFwLnNvbGFyU3lzdGVtTmFtZV1dID0gcGFyc2VJbnQoc29sYXJTeXN0ZW1JRCwgMTApO1xuXHRcdHRoaXMuc3lzTmFtZXMucHVzaChzeXN0ZW1bY29sbWFwLnNvbGFyU3lzdGVtTmFtZV0pO1xuXHRcdGlmICh0aGlzLnNwYWNlICE9IFwiSlwiKSB7XG5cdFx0XHQvLyBjcmVhdGUgdGhlIHJvdXRpbmcgZ3JhcGggdXNlZCBmb3IgcGF0aCBmaW5kaW5nXG5cdFx0XHRzeXMgPSB7XG5cdFx0XHRcdGp1bXBzOiBbXSxcblx0XHRcdFx0Y29udDogc3lzdGVtW2NvbG1hcC5jb250aWd1b3VzXSxcblx0XHRcdFx0c2VjOiBzeXN0ZW1bY29sbWFwLnNlY3VyaXR5XS50b0ZpeGVkKDEpLFxuXHRcdFx0XHRuYW1lOiBzeXN0ZW1bY29sbWFwLnNvbGFyU3lzdGVtTmFtZV1cblx0XHRcdH07XG5cdFx0XHRmb3IgKGkgPSAwOyBpIDwgc3lzdGVtW2NvbG1hcC5qdW1wc10ubGVuZ3RoOyBpKyspIHtcblx0XHRcdFx0dG9Tb2xhclN5c3RlbUlEID0gc3lzdGVtW2NvbG1hcC5qdW1wc11baV07XG5cdFx0XHRcdGlmICghc3lzdGJsLmRhdGEuaGFzT3duUHJvcGVydHkodG9Tb2xhclN5c3RlbUlEKSkgY29udGludWU7XG5cdFx0XHRcdHN5cy5qdW1wcy5wdXNoKHRvU29sYXJTeXN0ZW1JRCk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLnJvdXRlR3JhcGhbc29sYXJTeXN0ZW1JRF0gPSBzeXM7XG5cdFx0fVxuXHR9XG5cdHRoaXMuc3lzTmFtZXMuc29ydCgpO1xufVxuXG5QLkdldFN5c3RlbSA9IGZ1bmN0aW9uKGlucHV0KSB7XG5cdHZhciBuU3lzdGVtSUQsXG5cdFx0c1N5c3RlbUlEO1xuXG5cdGlmICghaW5wdXQpIHJldHVybiBudWxsO1xuXHRpZiAoaW5wdXQuaGFzT3duUHJvcGVydHkoXCJuYW1lXCIpICYmIHRoaXMuc3lzTmFtZU1hcC5oYXNPd25Qcm9wZXJ0eShpbnB1dC5uYW1lKSkgblN5c3RlbUlEID0gdGhpcy5zeXNOYW1lTWFwW2lucHV0Lm5hbWVdO1xuXHRlbHNlIGlmIChpbnB1dC5oYXNPd25Qcm9wZXJ0eShcImlkXCIpKSBuU3lzdGVtSUQgPSBwYXJzZUludChpbnB1dC5pZCwgMTApO1xuXHRlbHNlIHJldHVybiBudWxsO1xuXHRzU3lzdGVtSUQgPSBuU3lzdGVtSUQudG9TdHJpbmcoMTApO1xuXG5cdGlmICghc3lzX2NhY2hlLmhhc093blByb3BlcnR5KHNTeXN0ZW1JRCkpIHtcblx0XHRzeXNfY2FjaGVbc1N5c3RlbUlEXSA9IFN5c3RlbS5DcmVhdGUodGhpcy50YWJsZXNbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtc1wiXS50YmwsIG5TeXN0ZW1JRCk7XG5cdH1cblx0cmV0dXJuIHN5c19jYWNoZVtzU3lzdGVtSURdO1xufTtcblxuUC5HZXRTeXN0ZW1zID0gZnVuY3Rpb24oKSB7XG5cdHJldHVybiBTeXN0ZW1JdGVyLkNyZWF0ZSh0aGlzKTtcblx0Ly8gdGhpcy50YWJsZXNbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtc1wiXS50YmwpO1xufTtcblxuUC5KdW1wRGlzdCA9IGZ1bmN0aW9uKGZyb21JRCwgdG9JRCkge1xuXHR2YXIgc3lzdGJsID0gdGhpcy50YWJsZXNbXCJtYXBcIiArIHRoaXMuc3BhY2UgKyBcIlNvbGFyU3lzdGVtc1wiXS50YmwsXG5cdFx0Y29sbWFwID0gc3lzdGJsLmNvbG1hcCxcblx0XHR4MSA9IHN5c3RibC5kYXRhW2Zyb21JRF1bY29sbWFwLmNlbnRlcl1bMF0sXG5cdFx0eDIgPSBzeXN0YmwuZGF0YVt0b0lEXVtjb2xtYXAuY2VudGVyXVswXSxcblx0XHR5MSA9IHN5c3RibC5kYXRhW2Zyb21JRF1bY29sbWFwLmNlbnRlcl1bMV0sXG5cdFx0eTIgPSBzeXN0YmwuZGF0YVt0b0lEXVtjb2xtYXAuY2VudGVyXVsxXSxcblx0XHR6MSA9IHN5c3RibC5kYXRhW2Zyb21JRF1bY29sbWFwLmNlbnRlcl1bMl0sXG5cdFx0ejIgPSBzeXN0YmwuZGF0YVt0b0lEXVtjb2xtYXAuY2VudGVyXVsyXSxcblx0XHRkaXN0O1xuXG5cdGRpc3QgPSBNYXRoLnNxcnQoTWF0aC5wb3coeDEgLSB4MiwgMikgKyBNYXRoLnBvdyh5MSAtIHkyLCAyKSArIE1hdGgucG93KHoxIC0gejIsIDIpKTtcblx0cmV0dXJuIGRpc3QgLyBDb25zdC5NX3Blcl9MWTtcbn07XG5cblAuUm91dGUgPSBmdW5jdGlvbihmcm9tU3lzdGVtSUQsIHRvU3lzdGVtSUQsIGF2b2lkTGlzdCwgYXZvaWRMb3csIGF2b2lkSGkpIHtcblx0dmFyIHJvdXRlID0gW10sXG5cdFx0YXZvaWRzID0ge30sXG5cdFx0c0Zyb21JRCxcblx0XHRzVG9JRCxcblx0XHRzb2xhclN5c3RlbUlELFxuXHRcdGN1cnJlbnRJRCxcblx0XHRzeXN0ZW1JRCxcblx0XHRuSUQsXG5cdFx0cHJldklELFxuXHRcdHN5c190ZCxcblx0XHR0ZCxcblx0XHRpLFxuXHRcdHRtcCxcblx0XHR0ZXN0c2V0ID0gW10sXG5cdFx0dGVzdF90ZCxcblx0XHR0ZXN0aWR4LFxuXHRcdGRpc3Q7XG5cblx0c0Zyb21JRCA9IHBhcnNlSW50KGZyb21TeXN0ZW1JRCwgMTApLnRvU3RyaW5nKDEwKTtcblx0c1RvSUQgPSBwYXJzZUludCh0b1N5c3RlbUlELCAxMCkudG9TdHJpbmcoMTApO1xuXHRpZiAoIXRoaXMucm91dGVHcmFwaC5oYXNPd25Qcm9wZXJ0eShzRnJvbUlEKSB8fCAhdGhpcy5yb3V0ZUdyYXBoLmhhc093blByb3BlcnR5KHNUb0lEKSkgcmV0dXJuIHJvdXRlO1xuXG5cdC8vIHJlc2V0IHRoZSByb3V0ZSBncmFwaFxuXHRmb3IgKHNvbGFyU3lzdGVtSUQgaW4gdGhpcy5yb3V0ZUdyYXBoKSB7XG5cdFx0aWYgKCF0aGlzLnJvdXRlR3JhcGguaGFzT3duUHJvcGVydHkoc29sYXJTeXN0ZW1JRCkpIGNvbnRpbnVlO1xuXHRcdHRoaXMucm91dGVHcmFwaFtzb2xhclN5c3RlbUlEXS50ZCA9IC0xO1xuXHRcdHRoaXMucm91dGVHcmFwaFtzb2xhclN5c3RlbUlEXS5wcmV2SUQgPSAtMTtcblx0XHR0aGlzLnJvdXRlR3JhcGhbc29sYXJTeXN0ZW1JRF0udmlzaXRlZCA9IGZhbHNlO1xuXHR9XG5cblx0Ly8gcG9wdWxhdGUgYXZvaWQgbGlzdCBsb29rdXAgdGFibGVcblx0aWYgKGF2b2lkTGlzdCAmJiBhdm9pZExpc3QubGVuZ3RoID4gMCkge1xuXHRcdGZvciAoaSA9IDA7IGkgPCBhdm9pZExpc3QubGVuZ3RoOyBpKyspIHtcblx0XHRcdGF2b2lkc1thdm9pZExpc3RbaV1dID0gdHJ1ZTtcblx0XHR9XG5cdH1cblxuXHRpZiAoc0Zyb21JRCA9PT0gc1RvSUQpIHJldHVybiByb3V0ZTtcblxuXHQvLyBzd2FwIGZyb20vdG8gdG8gbWF0Y2ggRVZFIGNsaWVudD9cblx0dG1wID0gc0Zyb21JRDtcblx0c0Zyb21JRCA9IHNUb0lEO1xuXHRzVG9JRCA9IHRtcDtcblxuXHQvLyBEaWprc3RyYSdzIHRvIGZpbmQgYmVzdCByb3V0ZSBnaXZlbiBvcHRpb25zIHByb3ZpZGVkXG5cdGN1cnJlbnRJRCA9IHNGcm9tSUQ7XG5cdHRoaXMucm91dGVHcmFwaFtzRnJvbUlEXS50ZCA9IDA7XG5cdHdoaWxlICghdGhpcy5yb3V0ZUdyYXBoW3NUb0lEXS52aXNpdGVkKSB7XG5cdFx0aWYgKGN1cnJlbnRJRCAhPSBzRnJvbUlEKSB7XG5cdFx0XHQvLyBmaW5kIG5leHQgbm9kZSB0byB0cnlcblx0XHRcdHRlc3RfdGQgPSAtMTtcblx0XHRcdHRlc3RpZHggPSAtMTtcblx0XHRcdGZvciAoaSA9IDA7IGkgPCB0ZXN0c2V0Lmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRcdHN5c3RlbUlEID0gdGVzdHNldFtpXTtcblx0XHRcdFx0aWYgKHRoaXMucm91dGVHcmFwaFtzeXN0ZW1JRF0udmlzaXRlZCkgY29udGludWU7XG5cdFx0XHRcdGlmIChhdm9pZHNbc3lzdGVtSURdKSBjb250aW51ZTtcblx0XHRcdFx0c3lzX3RkID0gdGhpcy5yb3V0ZUdyYXBoW3N5c3RlbUlEXS50ZDtcblx0XHRcdFx0aWYgKHN5c190ZCA+IDAgJiYgKHRlc3RfdGQgPT0gLTEgfHwgc3lzX3RkIDwgdGVzdF90ZCkpIHtcblx0XHRcdFx0XHRjdXJyZW50SUQgPSBzeXN0ZW1JRDtcblx0XHRcdFx0XHR0ZXN0X3RkID0gc3lzX3RkO1xuXHRcdFx0XHRcdHRlc3RpZHggPSBpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAodGVzdF90ZCA9PSAtMSkgcmV0dXJuIHJvdXRlOyAvLyBubyBjb25uZWN0aW9uXG5cdFx0XHR0ZXN0c2V0LnNwbGljZSh0ZXN0aWR4LCAxKTsgLy8gcmVtb3ZlIHRoZSBub2RlIHdlIGp1c3QgcGlja2VkIGZyb20gdGhlIHRlc3RzZXRcblx0XHR9XG5cdFx0Zm9yIChpID0gMDsgaSA8IHRoaXMucm91dGVHcmFwaFtjdXJyZW50SURdLmp1bXBzLmxlbmd0aDsgaSsrKSB7XG5cdFx0XHRuSUQgPSB0aGlzLnJvdXRlR3JhcGhbY3VycmVudElEXS5qdW1wc1tpXTtcblx0XHRcdGRpc3QgPSAxO1xuXHRcdFx0Ly9pZiAoYXZvaWRMb3cgJiYgdGhpcy5yb3V0ZUdyYXBoW25JRF0uc2VjIDwgMC41ICYmIHRoaXMucm91dGVHcmFwaFtjdXJyZW50SURdLnNlYyA+PSAwLjUpIGRpc3QgPSAxMDAwO1xuXHRcdFx0aWYgKGF2b2lkTG93ICYmIHRoaXMucm91dGVHcmFwaFtuSURdLnNlYyA8IDAuNSkgZGlzdCA9IDEwMDA7XG5cdFx0XHQvL2lmIChhdm9pZEhpICYmIHRoaXMucm91dGVHcmFwaFtuSURdLnNlYyA+PSAwLjUgJiYgdGhpcy5yb3V0ZUdyYXBoW2N1cnJlbnRJRF0uc2VjIDwgMC41KSBkaXN0ID0gMTAwMDtcblx0XHRcdGlmIChhdm9pZEhpICYmIHRoaXMucm91dGVHcmFwaFtuSURdLnNlYyA+PSAwLjUpIGRpc3QgPSAxMDAwO1xuXHRcdFx0dGQgPSB0aGlzLnJvdXRlR3JhcGhbY3VycmVudElEXS50ZCArIGRpc3Q7XG5cdFx0XHRpZiAodGhpcy5yb3V0ZUdyYXBoW25JRF0udGQgPCAwIHx8IHRoaXMucm91dGVHcmFwaFtuSURdLnRkID4gdGQpIHtcblx0XHRcdFx0dGhpcy5yb3V0ZUdyYXBoW25JRF0udGQgPSB0ZDtcblx0XHRcdFx0dGhpcy5yb3V0ZUdyYXBoW25JRF0ucHJldklEID0gY3VycmVudElEO1xuXHRcdFx0XHR0ZXN0c2V0LnB1c2gobklEKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0dGhpcy5yb3V0ZUdyYXBoW2N1cnJlbnRJRF0udmlzaXRlZCA9IHRydWU7XG5cdFx0Y3VycmVudElEID0gMDtcblx0fVxuXG5cdC8vIGdldCB0aGUgYWN0dWFsIHJvdXRlIGZvdW5kXG5cdHByZXZJRCA9IHRoaXMucm91dGVHcmFwaFtzVG9JRF0ucHJldklEO1xuXHR3aGlsZSAocHJldklEICE9IHNGcm9tSUQpIHtcblx0XHRyb3V0ZS5wdXNoKHBhcnNlSW50KHByZXZJRCwgMTApKTtcblx0XHRwcmV2SUQgPSB0aGlzLnJvdXRlR3JhcGhbcHJldklEXS5wcmV2SUQ7XG5cdH1cblx0cm91dGUucHVzaChwYXJzZUludChzRnJvbUlELCAxMCkpO1xuXHQvLyByb3V0ZS5yZXZlcnNlKCk7XG5cdC8vIHJvdXRlLnVuc2hpZnQodG9TeXN0ZW1JRCk7XG5cdHJldHVybiByb3V0ZTtcbn07XG4iXX0=
